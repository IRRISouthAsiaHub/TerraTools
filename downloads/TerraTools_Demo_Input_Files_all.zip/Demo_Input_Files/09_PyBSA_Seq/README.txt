PyBSA-Seq - bulked segregant analysis with the G statistic  (run time about 1-3 minutes with 500 simulation replicates)

INPUT   input/pybsa_parents.tsv  and  input/pybsa_bulks.tsv   GATK4 VariantsToTable tables (CHROM, POS, REF, ALT, QUAL and <sample>.GT/.AD/.GQ):
        parents Parent1 / Parent2 (homozygous, different) and bulks HighBulk / LowBulk; 3,731 variants, one every ~100 kb along the 12 rice chromosomes.
        The bulks are the 20 tallest and 20 shortest lines of the mapping population (Plant_Height of demo 04, QTL on chr3 at 11.6 Mb and chr8 at 9.4 Mb); the allele of every SNP comes from the REAL
        marker genotypes of the neighbouring markers, the read counts (about 40 x, 1 % errors) are SIMULATED.

STEPS   Trait Mapping > PYBSA G-statistics > Parents file: pybsa_parents.tsv, Bulks file: pybsa_bulks.tsv.
        Bulk sizes 20,20   Population RIL   p-values 0.01,0.01   Replication 500 (default 10000)   Sliding window 2000000,10000   Smoothing 51,3
        Read length 100   Region -1 (all)   Misc 20,5,1   Parent reference: no.  > Run Analysis.

EXPECT  An HTML report and figures (expected_output/PyBSASeq.png, PyBSASeq_report.html, sv_region.csv, significant_sv_regions.png).  In the four-panel figure the G statistic and the delta allele
        frequency leave their simulated 99 % thresholds on chromosome 3 (peak about 10 Mb, G about 51, delta AF about -0.74) and chromosome 8 (peak about 11 Mb, G about 90, delta AF about -0.94) -
        the two planted regions (the tool's sign convention makes delta AF negative there).  A few small bumps just above the limits on chr1, 2, 4 and 5 (G 12-17)
        are chance linkage in 20-plant bulks.  The sSV/totalSV panel is very sensitive and marks many weak regions (sv_region.csv); use G and delta AF.
