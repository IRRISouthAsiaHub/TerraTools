ET-GWAS - extreme-trait GWAS, good for rare alleles  (run time about 5 s)

INPUT   input/etgwas_panel.csv   200 unrelated rice accessions (indica 2 sub-population of the rice 3K panel) x 482 SNPs (Chr_Position) + Phenotype. REAL genotypes, SIMULATED trait.
        answer_key_planted_loci.csv: a common SNP on chr3 (Chr3_7869953, MAF 0.38) and a RARE SNP on chr8 (Chr8_19368421, MAF 0.10) control the trait.

STEPS   Trait Mapping > ET-GWAS > Data: ready-made file > etgwas_panel.csv.   Bulks 20 %, MAF 0.05, FDR 0.05, merge 100 kb, genomic control ON.  > Run ET-GWAS.

EXPECT  Bulks of 40 lines (low / random / high), 482 SNPs tested, inflation factor lambda = 3.4 (the indica panel has structure; corrected by genomic control).
        Exactly two MTAs at FDR < 0.05, both Bonferroni significant:  Chr8_19368421 (the rare SNP, MAF 0.10, PVE 19.6 %, q = 2.5e-4) and Chr3_7869953 (MAF 0.38, PVE 30.6 %, q = 1.3e-3) - the two planted
        loci.  At both loci the minor allele raises the trait and is enriched in the high bulk; the counted (alternative) allele is the major one, so its delta allele frequency is negative.
