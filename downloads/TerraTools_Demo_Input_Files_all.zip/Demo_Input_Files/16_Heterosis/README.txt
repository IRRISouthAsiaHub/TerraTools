HETEROSIS - predict hybrid performance from the parents with a neural network  (run time about 2 minutes with the demo settings)

INPUT   input/het_train_phenotype.csv (ID, Yield_gain) and het_train_genotype.csv: 80 training lines x 315 SNPs.   input/het_parent_genotype.csv: 10 candidate parents.
        input/het_test_genotype.csv: 10 further lines to predict.  All 100 lines of the rice mapping population (MP001-MP100), REAL genotypes; SIMULATED trait (5 QTL, h2 0.9), a gain relative to a check
        (mean about 1.2, SD 1.6). The trait is kept near 0-3 on purpose: the network is not given a rescaled trait (see BreedSight).

STEPS   Genomic Selection > Heterosis > the four files.   F1 hybrids to report 5, parents 5, folds 3, epochs 250, batch 16, dropout 0.2, L1 0.001, L2 0.001.  > Run Prediction.
        (Defaults are 5 folds; the demo uses 3 so that it takes about two minutes.)

EXPECT  Cross-validation: Pearson r 0.66, R2 0.27, RMSE 1.34 - the network ranks lines fairly well (folds r 0.58 / 0.70 / 0.72).  45 hybrids (10 parents) are scored.
        Top F1 hybrid MP009 x MP008, predicted 1.47, mid-parent heterosis +27.5 %; the next four hybrids all use MP008 as a parent (MPH +6 to +14 %).  Mid-parent and best-parent heterosis are measured
        against the mean and the maximum of the TRAINING lines, so best-parent heterosis is negative (the best training line is better than any hybrid).  Top parents (MP008 1.19, MP009 0.46, MP083 0.38,
        MP030 0.34, MP053 0.24) and the test-line predictions are listed as well.  Neural-network results vary a little between runs.
