ADDITIVE DOMINANCE - genomic relationship matrices (rrBLUP A.mat, sommer D.mat)  (run time about 10 s)

INPUT   input/snp_matrix.csv   176 rice RILs x 288 SNPs, coded 0/1/2. REAL genotypes.

STEPS   Genomic Selection > Additive Dominance > Browse: snp_matrix.csv.   Missing values: mean.   Matrices: Additive + Dominance.  > Compute Matrices.

EXPECT  176 samples x 288 markers, no missing data, 288 markers above the MAF filter, none monomorphic.
        Additive matrix: diagonal about 1.93 (RILs are nearly homozygous), mean off-diagonal about 0.  Heat maps show blocks of related lines along the diagonal.
        Downloads: Additive_Matrix.csv and Dominance_Matrix.csv.
