GWAS - genome-wide association with three models  (run time about 15 s)

INPUT   input/gwas_ready.csv   ID, Phenotype (PH, plant height) and 278 SNP columns (Chr_Position) of 100 rice RILs (the mapping population) - the ready-made format.
        input/genotypes.vcf.gz + phenotypes.csv   the same data as VCF + trait table (second input route; phenotypes.csv has PH, PL, GYKGHA and AGR).
        Genotypes and traits REAL (the lines of the QTL Mapping demo).
        input/gwas_ready_position_rows.csv   the same genotypes in the layout with a Position row and a Chromosome row under the header
        (marker names are plain m1, m2, ...; positions come from the rows - the layout Linkage Mapping writes).

STEPS   Trait Mapping > GWAS > Data & Models: ready-made GWAS file > gwas_ready.csv.  Models: OLS, MLM, FarmCPU.  > Run GWAS.

EXPECT  Manhattan plot with one panel per model plus the QQ plot and the circular plot.  Genome-wide significant SNPs (Bonferroni p <= 1.8e-4): OLS 4 (all on chr1: Chr1_38632196 p 5e-16,
        Chr1_36150523 and Chr1_36419842 p 1e-13, Chr1_39955529 p 5e-6), MLM 3 (the first three, p 5e-8 to 4e-7), FarmCPU 3 - Chr1_38632196 (p 2e-13), Chr4_30438901 (p 2e-5) and Chr2_316859 (p 2e-5):
        the three QTL of the QTL Mapping demo, the strongest next to SD1.
        Inflation (lambda): OLS 1.65, MLM 0.76, FarmCPU 0.91.
