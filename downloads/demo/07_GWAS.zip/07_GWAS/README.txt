GWAS - genome-wide association of rice blast resistance with three models  (run time about 1 minute)

INPUT   input/gwas_ready.csv   ID, Phenotype (Blast_resistance score 0-9, as in GSTP009.pheno.csv) and 5,000 SNP columns (Chr_Position) of 356 rice inbred lines (diversity panel GSTP009) - the ready-made format.
        input/genotypes.vcf.gz + input/phenotypes_blast.csv   the same data as VCF + trait table (ID, Blast_resistance): the second input route.
        input/gwas_ready_position_rows.csv   the same genotypes in the layout with a Position row and a Chromosome row under the header (marker names are plain m1, m2, ...; positions come from the rows).
        input/phenotypes_3K_panel.csv   the third route: trait values (SampleID, Disease) of accessions of the rice 3K panel that is bundled with the app (IRIS ids); choose "Rice 3K panel" and this file. It does not belong to the blast data.
        The 5,000 SNPs are evenly spaced along the genome (IRGSP-1.0 positions) from the 3.4 million SNPs of the panel with minor allele frequency >= 0.05, at most 2 % missing and no more than 5 % heterozygous calls; the dosage counts
        copies of the first allele of the PLINK .bim file (the ALT allele of the VCF). Phenotype values are copied unchanged. Line ids are those of the source files.

STEPS   Trait Mapping > GWAS > Data & Models: ready-made GWAS file > gwas_ready.csv (or VCF + phenotype file: genotypes.vcf.gz, phenotypes_blast.csv, trait Blast_resistance; the prepared data are identical).
        Models: OLS, MLM, FarmCPU.  > Run GWAS.

EXPECT  Manhattan plot with one panel per model, the QQ plot and the circular plot (expected_output/).  Bonferroni threshold p <= 1e-5 (0.05 / 5,000 SNPs).
        OLS (no correction for relatedness): 1,897 "significant" SNPs, lambda 26. A diversity panel has strong population structure, so the OLS result is mostly structure; it is the uncorrected baseline.
        MLM (kinship): no genome-wide significant SNP, lambda 1.00.
        FarmCPU: 5 genome-wide significant SNPs, lambda 0.94 - Chr7_29595503 (p 5e-11), Chr4_24857805 (p 4e-8), Chr6_24138380 (p 3e-7), Chr12_22445445 (p 3e-7) and Chr2_29413333 (p 6e-6).
        Blast resistance in a diversity panel is polygenic and a 356-line panel has little power: treat the FarmCPU SNPs as candidates, not as proof. The QTL Mapping demo (04) used another SNP set
        (1,249 SNPs, one per 300 kb) and found QTL on chr3, 4, 9 and 12.
