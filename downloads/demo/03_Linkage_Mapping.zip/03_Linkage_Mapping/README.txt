LINKAGE MAPPING - coded genotypes to a genetic map  (run time about 30 s)

INPUT   input/2_coded_genotypes_RIL.csv   334 markers x 100 rice RILs (the mapping population MP001-MP100) coded 0/1/2 (Marker, Chromosome, then one column per line). REAL genotypes.
        Raw allele calls from a genotyping company (HapMap, VCF, A:G sheets) are converted first by the Genofile Converter: see 19_Genofile_Converter, which writes this file (it also leaves out
        the 11 faulty markers that the raw files contain).

STEPS   Trait Mapping > Linkage Mapping > Upload tab > Browse: 2_coded_genotypes_RIL.csv (or "Open in Linkage Mapping" from the Genofile Converter).
        Upload tab: population RIL.  Parameters: defaults (missing 0.30, max recombination 0.45, best marker order).  > Run Analysis.

EXPECT  QC Report: 334 markers kept, none removed.  Map: 12 chromosomes, about 1,620 cM in total (chr1 218, chr2 199, chr3 216, chr4 163, chr5 144, chr6 130, chr7 97, chr8 129, chr9 35,
        chr10 110, chr11 99, chr12 83 cM; chr9 has only 6 markers).  The marker order follows the physical order given by the marker names (Physical Map sheet).
        The "QTL Mapping input (CSV)" button writes the genotypes with the map positions: expected_output/2_coded_genotypes_RIL_for_QTL.csv, the file of the QTL Mapping demo (04) and the source
        of the Genotype Viewer, Heterosis, OCS, GWAS and BSA demos.
        expected_output/ also holds the linkage map, marker density and recombination heat map figures and the workbooks (linkage_results.xlsx with the map, recombination, QC and chromosome sheets).
