LINKAGE MAPPING - coded genotypes to a genetic map  (run time about 30 s)

INPUT   input/2_coded_genotypes_RIL.csv   310 markers x 100 rice RILs (the mapping population IR127304-1002 ... IR127304-1280) coded 0/1/2 (Marker, Chromosome, then one column per line). REAL genotypes.
        Raw allele calls from a genotyping company (HapMap, VCF, A:G sheets) are converted first by the Genofile Converter: see 19_Genofile_Converter, which writes this file (it also leaves out
        the 315 markers of the raw sheet that carry no information).

STEPS   Trait Mapping > Linkage Mapping > Upload tab > Browse: 2_coded_genotypes_RIL.csv (or "Open in Linkage Mapping" from the Genofile Converter).
        Upload tab: population RIL.  Parameters: defaults (missing 0.30, max recombination 0.45, best marker order).  > Run Analysis.

EXPECT  QC Report: 310 markers in, 5 removed for more than 30 % missing data, 19 removed during map construction (11 weakly linked, 7 poor fit, 1 linked more strongly to another chromosome), 286 kept.
        Map: 12 chromosomes, about 2,082 cM in total (chr1 218, chr2 253, chr3 199, chr4 206, chr5 96, chr6 149, chr7 108, chr8 240, chr9 68, chr10 200, chr11 180, chr12 165 cM). The maps are long
        because the markers are sparse and a RIL map stretches the distances; chr4, chr5 and chr11 each hold one unlinked interval counted as 50 cM. The marker order follows the physical order given by
        the marker names (Physical Map sheet) on every chromosome except chr12 (rank correlation 0.36: the chr12 markers are strongly distorted, demo 02).
        The "QTL Mapping input (CSV)" button writes the genotypes with the map positions: expected_output/2_coded_genotypes_RIL_for_QTL.csv, the file of the QTL Mapping demo (04) and the source
        of the Genotype Viewer, Heterosis, OCS, GWAS and BSA demos.
        expected_output/ also holds the linkage map, marker density and recombination heat map figures and the workbooks (linkage_results.xlsx with the map, recombination, QC and chromosome sheets).
