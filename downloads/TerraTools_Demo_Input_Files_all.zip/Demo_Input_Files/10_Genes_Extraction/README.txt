GENES EXTRACTION - genes inside the QTL of QTL Mapping  (run time 1-2 s)

The QTL table AND the marker position file are both required (the file gives the base-pair position of the QTL markers). If you have no such table, give a VCF instead.

INPUT   input/qtl_table_cM_markers_without_position.csv  the QTL table of QTL Mapping for PH (CIM, permutation threshold; demo 04), positions in cM, whose markers were renamed M001..M008,
                                                          so the names say nothing about the genome.
        input/marker_positions.csv  the genetic map with the bp of those markers (Marker, Chromosome, bp).
        input/marker_positions.vcf  the same markers as a VCF (CHROM, POS, ID), for the case WITHOUT a genetic map.
        input/annotation_IRGSP1_regions.gff3   1,254 real rice genes (IRGSP-1.0, RAP-DB annotation from Ensembl Plants) of the regions of the three PH QTL: chr1 36.3-40.1 Mb (with SD1 at 38.38 Mb),
                                               chr2 0.2-0.6 Mb and chr4 29.4-33.2 Mb.

STEPS   Trait Mapping > Genes Extraction > QTL results: the QTL table > Marker position file: marker_positions.csv > annotation: the GFF3 > overlap > Run.
        With no marker table: choose "Use a VCF" and select marker_positions.vcf.

EXPECT  Three QTL regions, QTL_1.1 on chr1 (36.48-38.76 Mb, 349 genes), QTL_2.1 on chr2 (0.32-0.41 Mb, 9 genes) and QTL_4.1 on chr4 (29.86-31.20 Mb, 207 genes), 565 genes in all (position, strand, biotype)
        and a gene ID list for Gene Prioritization. The chr1 region contains Os01g0883800 (SD1). The confidence interval in cM is placed on the genome between the markers of each QTL.
        Genes Extraction takes the QTL table of QTL Mapping only: a GWAS table or a table of intervals in bp is refused.
