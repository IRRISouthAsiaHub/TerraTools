BREEDSIGHT - AMYLOSE CONTENT IN 357 RICE INBRED LINES (GSTP009)  (run time about 2-4 minutes with the settings below)

DATA    370 of the 378 lines of the GSTP009 data have an amylose-content value. They were split at random (seed 7, 20 % testing) into 296 training and 74 testing lines, and then the 13 TRAINING
        lines with a value below 10 were removed: 283 training lines (input/training.csv) remain. The 74 testing lines (input/testing.csv; their phenotypes are included, so BreedSight also reports
        an independent test result) were not touched; none of them has a value below 10. The 8 lines without a value are not in the files. Line ids are the ones of the source files.
        Removed from the training set (value): 76f56677.0 (0.21), 407f31bd.0 (1.12), 64fa0112.0 (0.37), 5b144b9c.0 (0.45), 5497b233.0 (0.06), eb17cda6.0 (0.35), e59cbfbe.0 (0.06),
        a08839ce.0 (9.83), a53530c6.0 (0.12), 8629f76c.0 (8.59), ba028784.0 (0.00), 743f41c1.0 (0.10), 1a95985b.0 (0.40).

SOURCE  GSTP009.xlsx, sheet "breedsight" (LINE, Amylose_content; the same values are in the amylose column of the sheet "GSTP009") and the genotypes 378Rice_Inbred.bed / .bim / .fam
        (5,231,433 SNPs, IRGSP-1.0 positions).

WHAT WAS DONE TO THE RAW FILES
        1. The phenotype values are copied EXACTLY as they are in the sheet (percent amylose, for example 15.61333333): no z-score, no rescaling, no rounding. The only change is the removal of
           the 13 training lines above. The 283 training lines have a mean of 20.39 and an SD of 4.32 (lowest value 10.29, highest 27.87).
        2. SNPs with more than 10 % missing calls or a minor allele frequency below 0.05 (in the 370 lines) were removed: 3,502,539 of 5,231,433 SNPs passed, and 50,000 of them, evenly
           spaced along the genome, were used. The calls are 0/1/2 copies of the first allele of the .bim file; the panel has no missing calls.
        3. The additive matrix is VanRaden (2008): G = (M - 2p)(M - 2p)' / 2 sum p(1-p), with the allele frequencies p of the 283 TRAINING lines only.
           training_additive.csv is training x training (columns 1..283 = the training lines in the order of training.csv); test_additive.csv is testing x training.
           The testing lines therefore never influence the training matrix. The lines are inbred, so the diagonal of G is about 2 (mean 1.97), not 1.

STEPS   Genomic Selection > BreedSight GUI > the four files (input/training.csv, input/training_additive.csv, input/testing.csv, input/test_additive.csv).
        Cross-validation folds 2, heritability 0.8, epochs 50; every other setting at its default (batch 32, learning rate 0.001, DNN weight 0.4, L2 0.001,
        dropout 0.2, RF trees 300, RF depth 0 = None, PCA on with 50 components, feature selection on (100), "Use raw genotypes" OFF); compare with Lasso,
        RBLUP and GBLUP.  > Run.  (The default of 5 folds and 300 epochs takes longer.)

EXPECT  Validation R2 / correlation of the 2-fold cross-validation (expected_output holds the run), and the same on the 74 independent testing lines:
                          2-fold cross-validation        74 testing lines
        BreedSight           0.56 / 0.76                    0.59 / 0.77   (95% CI of R2 0.45 - 0.70, of r 0.69 - 0.84)
        RBLUP                0.53 / 0.74                    0.48 / 0.69
        Lasso                0.52 / 0.74                    0.41 / 0.65
        GBLUP                0.48 / 0.71                    0.36 / 0.61
        BreedSight is best on both. The neural network is random: results vary by a few hundredths between runs.

HONEST NOTES
        - Removing the low-amylose training lines narrows the range of the training values (SD 4.32 instead of 5.75 with them), and the cross-validation R2 is measured on lines of that
          narrower range, so it is higher than it would be with all lines and is not comparable with a run that includes them. A model trained this way cannot predict values below about 10;
          the testing lines happen to contain none, so the test result does not show this.
        - Amylose content is controlled mostly by one major gene (Waxy) plus modifiers, which is why it is predicted much better than a complex trait. Because a few loci dominate,
          the lines of a diversity panel that share a haplotype there share a value, and part of the prediction may come from the population structure of the panel.
        - The test R2 rests on only 74 lines (see the interval); the cross-validation uses 283 lines and two folds (R2 varies by 0.07 between them).
        - Only the amylose sheet was used, so the trait was not chosen after looking at results.
