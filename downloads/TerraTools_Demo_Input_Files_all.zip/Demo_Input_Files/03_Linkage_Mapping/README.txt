LINKAGE MAPPING - raw allele calls to a genetic map  (run time: convert 2 s, map about 25 s)

INPUT   input/1_raw_allele_calls.csv   345 markers: Marker, Chromosome, P1, P2 and one column per RIL, calls like C:G. Real genotypes, simulated allele letters,
                                       11 deliberately faulty markers (answer_key_faulty_markers.csv).
        input/2_coded_genotypes_RIL.csv  the same data already coded 0/1/2 - the shortcut start at the Upload tab.

STEPS   Trait Mapping > Linkage Mapping > Convert Alleles > Browse: 1_raw_allele_calls.csv > Convert > Use in Linkage Mapping.
        Upload tab: population RIL.  Parameters: defaults (missing 0.30, max recombination 0.45, best marker order).  > Run Analysis.

EXPECT  Convert: 345 markers read, 334 coded, 11 left out (3 missing parent, 4 heterozygous parent, 4 same allele in both parents).
        QC Report: 334 markers kept.  Map: 12 chromosomes, about 1360 cM in total.  The "QTL Mapping input (CSV)" button writes the genotypes with the map positions.
