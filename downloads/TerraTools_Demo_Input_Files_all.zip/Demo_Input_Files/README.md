# TerraTools demo input files

Small, purpose-built inputs for all 16 tools. Each folder holds `input/` (the files to load), `expected_output/` (what the tool produced when we ran it, so you can compare)
and `README.txt` (the exact settings to enter, the run time and the numbers you should see).

| # | Tool | Run time* | Headline result |
|---|------|-----------|-----------------|
| 01 | Phenotypic Data Analysis | 20 s | Yield heritability 0.52 (plot) / 0.76 (entry mean); Wet_2024 yields most |
| 02 | Mendelian Segregation | 10 s | 104 of 334 markers distorted, 230 kept |
| 03 | Linkage Mapping | 2 s + 25 s | 345 markers read, 334 mapped, 11 faulty markers caught; 12 chromosomes |
| 04 | QTL Mapping | 5 s per run | CIM finds the 2 planted Yield QTL (chr1, chr5); the control trait gives none |
| 05 | QTL-Seq | 10 s | One QTL on chr2, 8.8-15.2 Mb, peak 11.9 Mb (planted: 12 Mb) |
| 06 | Diversity Analysis | 10 s | Shannon 0.36 -> 1.09 over 5 varieties; clusters equal the varieties |
| 07 | GWAS | 12 s | OLS 31 / MLM 4 / FarmCPU 2 significant SNPs; FarmCPU: chr1 and chr5 |
| 08 | ET-GWAS | 10 s | Two MTAs: the planted common SNP (chr3) and the planted rare SNP (chr8) |
| 09 | PyBSA-Seq | 50 s | A single significant region on chr2 (about 4.7-15 Mb) |
| 10 | Genes Extraction | 2 s | 22 genes in the QTL intervals, 102 near the GWAS markers |
| 11 | Gene Prioritization | about 3 min (needs internet) | 6 known yield genes score 42-54, 2 controls score 0 |
| 12 | Clustering & Genomic Selection | 5 s | 5 clusters; 140 train / 36 test |
| 13 | Additive Dominance | 10 s | 176 x 176 additive and dominance matrices |
| 14 | BreedSight | 75 s | Validation r 0.67-0.75 for all four models (RBLUP best) |
| 15 | Optimal Cross Selection | 8 s | 20 crosses, 12 parents, far lower inbreeding than truncation selection |
| 16 | Heterosis | 90 s | Cross-validation r 0.63; top hybrid BSP2-121 x BSP2-80 |

\* Measured on the development PC with the settings in each README (some use fewer simulation replicates, epochs or folds than the defaults to stay well under 5 minutes).

**What is real and what is simulated.** The genotypes in tools 02-04, 07, 12-16 come from 176 real rice RILs; the traits (and all data of tools 01, 05, 06, 08, 09), bulks, haplotype blocks and panels are simulated with known answers
(each README says what was planted), so you can see that the tool finds it. Gene Prioritization uses real rice genes and live public databases, so its scores can drift slightly.
Results of the neural-network tools (BreedSight, Heterosis) vary a little between runs.
