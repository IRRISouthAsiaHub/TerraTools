GWAS - genome-wide association with three models  (run time about 15 s)

INPUT   input/gwas_ready.csv   ID, Phenotype (Yield) and 315 SNP columns (Chr_Position) of 100 rice RILs (the mapping population) - the ready-made format.
        input/genotypes.vcf.gz + phenotypes.csv   the same data as VCF + trait table (second input route; phenotypes.csv has Yield and Plant_Height).
        Genotypes REAL, trait SIMULATED (the Yield of the QTL Mapping demo: QTL on chr1 at chr01_20562598 and chr5 at chr05_7328783).
        input/gwas_ready_position_rows.csv   the same genotypes in the layout with a Position row and a Chromosome row under the header
        (marker names are plain m1, m2, ...; positions come from the rows - the layout Linkage Mapping writes).

STEPS   Trait Mapping > GWAS > Data & Models: ready-made GWAS file > gwas_ready.csv.  Models: OLS, MLM, FarmCPU.  > Run GWAS.

EXPECT  Manhattan plot with one panel per model plus the QQ plot and the circular plot.  Genome-wide significant SNPs (Bonferroni p <= 1.6e-4): OLS 16 (all in the two regions, in blocks of linkage
        disequilibrium: 10 on chr1, 6 on chr5), MLM 2, FarmCPU 2 - Chr1_20562598 and Chr5_7328783, exactly the two planted markers (FarmCPU p 1e-15 and 4e-12).
        Inflation (lambda): OLS 2.21, MLM 1.05, FarmCPU 1.36 - the mixed model removes the inflation of the uncorrected OLS.
