CLUSTERING & GENOMIC SELECTION - PCA + k-means and a training/testing split  (run time about 5 s)

INPUT   input/snp_matrix.csv   100 rice RILs (the mapping population) x 315 SNPs (Sample, then SNPs coded 0/1/2, one SNP per position, minor allele frequency >= 0.10; missing calls filled with the
        commoner class). REAL genotypes.

STEPS   Genomic Selection > Clustering & Genomic Selection > Browse: snp_matrix.csv.   Clusters 5, test size 0.20.  > Run Clustering & Split.

EXPECT  100 samples, 315 markers, 5 clusters (sizes 18 / 18 / 23 / 28 / 13), a stratified split: 80 training and 20 testing samples.
        PC1 explains 6.4 % and PC2 6.0 % of the variance (a RIL population has weak structure; the K selection figure suggests K = 2). A second figure (K selection) shows the silhouette width and the elbow
        for K = 2 to 10; "Principal components used" (default all) can be set to the first 5 to 20. Download the training and testing sets: they are the input of the next steps.

NEXT    With a phenotype file (sample_id, phenotypes) chosen as well (for example Yield from 07_GWAS/input/phenotypes.csv), the training file also gets the phenotypes column.  The "Relationship matrices"
        button then opens Additive Dominance with the training and testing files already filled in, to compute the matrices of those two files.
