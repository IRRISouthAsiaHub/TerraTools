GENES EXTRACTION - genes inside the QTL of the rice blast QTL Mapping demo 04  (run time 1-2 s)

The QTL table AND the marker position file are both required (the file gives the base-pair position of the QTL markers). If you have no such table, give a VCF instead.

INPUT   input/qtl_table_cM_markers_without_position.csv  the QTL table of QTL Mapping for Blast_resistance (CIM, permutation threshold; demo 04: 356 rice inbred lines, GSTP009 data),
                                                          positions in cM, whose markers were renamed M001..M012, so the names say nothing about the genome.
        input/marker_positions.csv  the map with the bp of those markers (Marker, Chromosome, bp).
        input/marker_positions.vcf  the same markers as a VCF (CHROM, POS, ID), for the case WITHOUT a genetic map.
        input/annotation_IRGSP1_regions.gff3   433 real rice genes (IRGSP-1.0, RAP-DB annotation from Ensembl Plants) of the four QTL regions, with 150 kb on each side of the flanking markers:
                                               chr3 9.95-10.85 Mb, chr4 31.18-32.24 Mb, chr9 4.82-5.62 Mb and chr12 11.95-13.14 Mb.

STEPS   Trait Mapping > Genes Extraction > QTL results: the QTL table > Marker position file: marker_positions.csv > annotation: the GFF3 > Run.
        Every other setting stays at its default (confidence interval of the QTL, genes inside the region).
        With no marker table: choose "Use a VCF" and select marker_positions.vcf.

EXPECT  Four QTL regions and 98 genes in all (position, strand, biotype) and a gene ID list for Gene Prioritization (the VCF gives the same result):
            QTL_3.1   chr3   10.23-10.44 Mb   39 genes
            QTL_4.1   chr4   31.51-31.69 Mb   23 genes, including GSD1 (Os04g0620200) and two genes named Pi63 (Os04g0620800, Os04g0620950), a blast-resistance gene symbol
            QTL_9.1   chr9    5.09-5.26 Mb    15 genes
            QTL_12.1  chr12  12.34-12.80 Mb   21 genes
        The confidence interval in cM is placed on the genome between the markers of each QTL.
        Genes Extraction takes the QTL table of QTL Mapping only: a GWAS table or a table of intervals in bp is refused.

HONEST NOTES
        - The map of demo 04 is a pseudo map (base pairs x 4.3 cM per Mb) because the lines are unrelated inbreds, so the width of each interval comes from the 300 kb marker spacing and the
          LOD curve, not from real recombination. In a diversity panel the true resolution is set by linkage disequilibrium and the population structure (see the notes of demo 04), so read
          these regions as candidate intervals.
        - "From the left to the right flanking marker" gives wider regions: choose it when you want to be safe.
        - The annotation file holds the genes of these regions only (433 genes), not the whole genome; use a full GFF3 for your own data.
