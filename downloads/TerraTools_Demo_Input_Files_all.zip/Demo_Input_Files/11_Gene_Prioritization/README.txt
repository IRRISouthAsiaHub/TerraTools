GENE PRIORITIZATION - rank candidate genes with public databases  (needs the internet; about 3 minutes the first time)

INPUT   input/candidate_genes.txt   8 rice genes (RAP-DB IDs): six well-known plant-height (gibberellin / brassinosteroid pathway) genes - SD1 / GA20ox2 (Os01g0883800, inside the chr1 QTL of the QTL Mapping
        demo 04 and the Genes Extraction demo 10), D18 / GA3ox2 (Os01g0177400), GID1 (Os05g0407500), D1 / RGA1 (Os05g0333200), SLR1 (Os03g0707600), D11 (Os04g0469800) - and two controls with no
        plant-height role: Os02g0105300 (a gene of the chr2 QTL region with only a clone name) and Os01g0545100 (OsMYB86-L1).

STEPS   Trait Mapping > Gene Prioritization > Species: rice.  Trait: plant height.  Gene list: candidate_genes.txt. > Run.

EXPECT  The six known plant-height genes rank on top with the evidence level "Direct association": D18 71.8, GID1 66.5, SD1 (C20ox2) 65.9, D11 63.3, D1 60.0, SLR1 39.9 (scores of 100).
        The controls come last: Os02g0105300 15.1 ("Single line": one weak category) and Os01g0545100 0.0 ("No trait evidence").
        Evidence comes from Gramene trait annotations, Oryzabase curated gene names and trait classes (downloaded once and cached, nothing is added to the app), Plant Reactome pathways and PubMed co-mentions; each gene also gets a RAP-DB link; the score ranks the evidence, it is not a probability.
NOTE    The time depends on how fast Ensembl Plants, Gramene, Plant Reactome, NCBI and Oryzabase answer: about 3 minutes (the Oryzabase list, about 11 MB, is fetched once) for the first run, seconds for a repeat (the app caches answers).
        Scores can change a little over time. The gene ID list that Genes Extraction writes for the PH QTL of demo 10 (565 genes) can be used here too, but it takes much longer (30 minutes or more).
