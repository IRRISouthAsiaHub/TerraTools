LINKAGE MAPPING - coded genotypes to a genetic map  (run time about 1 minute)

INPUT   input/2_coded_genotypes_RIL.csv   300 SNPs x 356 rice inbred lines (the GSTP009 panel, the lines of the blast-resistance demos), coded 0 / 1 / 2 (Marker, Chromosome, then one column per line; 0 = major homozygote,
        2 = minor homozygote). The SNPs are evenly spaced along the 12 chromosomes (IRGSP-1.0; the position is in the marker name chrNN_bp) from those with minor allele frequency >= 0.20 and no missing or heterozygous call.

STEPS   Trait Mapping > Linkage Mapping > Upload tab > Browse: 2_coded_genotypes_RIL.csv.  Upload tab: population RIL.  Parameters: defaults (missing 0.30, max recombination 0.45, best marker order).  > Run Analysis.

EXPECT  QC Report: 300 markers in, 174 removed during map construction (171 of them linked more strongly to another chromosome), 126 kept on 11 chromosomes (chr9 has no marker left). Map lengths: chr1 119.5, chr2 67.1,
        chr3 19.4, chr4 115.4, chr5 29.9, chr6 26.5, chr7 29.6, chr8 142.5, chr10 125.7, chr11 13.5, chr12 59.7 cM. expected_output/ holds the figures (linkage map, marker density, recombination heat map), the workbooks and
        2_coded_genotypes_RIL_for_QTL.csv (the "QTL Mapping input (CSV)" button).

NOTE    A linkage map needs a population from a cross, where recombination shapes the genotypes. These lines are unrelated: the association between two markers is linkage disequilibrium of the panel, strong even between
        chromosomes (population structure), not recombination. The tool therefore removes most markers as "linked to another chromosome", the map order does not follow the genome (rank correlation of cM with bp 0.06 - 0.49 on 8 chromosomes,
        "map order differs from the genome"; 0.53 - 0.83 on chr4, 5 and 7, "partly out of order") and the lengths in cM are not real genetic distances. The demo shows the steps and the outputs of the tool on this panel; for a real map use a biparental population (RIL, F2, DH, BC).
        The QTL Mapping demo (04) uses a pseudo map (4.3 cM per Mb) instead of this one.
