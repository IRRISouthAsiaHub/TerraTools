MENDELIAN SEGREGATION - find markers that do not follow the expected ratio  (run time about 10 s)

INPUT   input/coded_genotypes_RIL.csv   310 markers x 100 rice RILs (the mapping population IR127304-1002 ... IR127304-1280), coded 0/1/2: Marker, Chromosome, then one column per line.
        REAL genotypes (the table the Genofile Converter writes, demo 19).

STEPS   Trait Mapping > Mendelian Segregation > Browse: coded_genotypes_RIL.csv
        Population type: RIL (classes 0 and 2 in 1:1, exact binomial test).  Alpha 0.10.  Correction: FDR (Benjamini-Hochberg, the default).  Missing codes: NA, ., -9, -1.  > Run Segregation Test.

EXPECT  310 markers tested, none inconclusive. The 99 heterozygous calls of the RILs (0.3 %) are not part of the test and are listed in the summary.
        This real population is far from a clean 1:1: many markers are distorted.
        FDR, alpha 0.10 (expected_output):  93 flagged distorted, 217 pass the quality check (results_filtered.csv, markers_LMready.xlsx).
                         Distorted per chromosome: chr12 27, chr8 12, chr2 10, chr3 10, chr7 9, chr11 7, chr10 6, chr1 4, chr5 4, chr4 3, chr9 1 (chr6 none). The strongest markers are chr05_18405433
                         (94 : 6 lines, parent 1 in excess), chr08_28125942 (76 : 2) and chr05_18108765 (93 : 7).
        Bonferroni, alpha 0.10:   65 distorted, 245 pass (chr12 22, chr7 9, chr2 8, chr8 8, chr3 6 ...).
        None (raw p, alpha 0.05): 101 distorted, 209 pass - uncorrected testing flags more markers.
        FDR, alpha 0.05:          84 distorted, 226 pass.
        Three plots: manhattan.png (segregation plot): -log10(p) along the markers, one colour per chromosome, dashed line = cut-off of the correction; heterozygosity.png: % heterozygous calls per marker;
        rateplot.png (distortion summary): % distorted markers per chromosome (chr12 stands out - the same chromosome whose linkage map of this population did not follow the genome order; demo 03 now holds the GSTP009 panel).
        markers_LMready.xlsx: the passing markers (Marker, Chromosome, genotypes), ready to load in Linkage Mapping.

OTHER POPULATIONS  Choose BC1P1 / BC1P2 (1:1), F2 (1:2:1), F3 (3:2:3) or F4 (7:2:7) for those generations: each has its own model, F1 is refused, and a marker with too few calls to reach alpha is
        reported as inconclusive (column call), neither distorted nor passed. A population that is mostly one parent on every chromosome (for example a backcross-derived set run as RIL) shows almost
        every marker distorted; choose a type that fits the generation or treat the test only as a quality check.
