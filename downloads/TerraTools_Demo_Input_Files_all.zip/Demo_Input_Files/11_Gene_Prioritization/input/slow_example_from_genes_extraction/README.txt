The chain from Genes Extraction: the 22 genes of the two QTL (candidate_genes.txt) are the gene list of Gene Prioritization.
Load candidate_genes.txt as the gene list (species rice, trait grain yield). It takes several minutes with a cold cache (waiting for the public servers).
