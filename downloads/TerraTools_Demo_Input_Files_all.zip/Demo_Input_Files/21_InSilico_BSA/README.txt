IN SILICO BSA - bulked segregant analysis from the genotype and trait of every line   (run time: about 10 s)

INPUT   input/genotypes_RIL.csv   3,731 SNPs on the 12 rice chromosomes (CHROM, POS, ID, then one column per line), 100 rice RILs coded 0 / 2 (0 = parent 1, 2 = parent 2). One SNP every ~100 kb: the allele
        of each SNP is taken from the REAL marker genotypes of the neighbouring markers of the mapping population (a crossover falls at a random place between two markers that differ).
        input/phenotypes.csv     Sample, PlantHeight (the first column holds the line names exactly as in the genotype file). SIMULATED on the real genotypes (the Plant_Height of demo 04):
        planted QTL on chr3 at 11.64 Mb (+4.0) and chr8 at 9.40 Mb (+2.8).

STEPS   Trait Mapping > In silico BSA > Browse: genotypes_RIL.csv, then the phenotype file phenotypes.csv (trait PlantHeight).
        Pools 20 % (20 + 20 lines), population type: RIL, primary window 1000 kb, window sizes 500 / 1000 / 2000 kb, merge regions closer than 2000 kb, 1000 permutations, level 0.05.  > Run Analysis.

EXPECT  2 loci, each found by all three window sizes; 2 significant regions at every size. Gw threshold of the 500 kb windows 7.19 (1 Mb: 6.66, 2 Mb: 6.09). At the 1 Mb size:
        L1 chr8 6.0-23.0 Mb, peak 10.0 Mb (adjusted p 0.001, LOD 10.3, delta SNP-index +0.95): a long unrecombined block, the planted locus is at 9.4 Mb;
        L2 chr3 10.0-12.0 Mb, peak 11.3 Mb (adjusted p 0.001, LOD 6.2, delta +0.80): the planted locus is at 11.6 Mb.
        SNP-index view (snp_index_tracks.png, the first figure; the SNP-index is the frequency of the parent 2 allele, dSNP-index = high pool - low pool, positive: the parent 2 allele goes with the taller
        plants): 7 peak regions outside the 99 % interval of the permutations (snp_index_regions.csv): D1 chr8 4.9-24.1 Mb (delta +0.95) and D2 chr3 7.7-13.1 Mb (delta +0.79, peak chr3_11665889) are the two
        planted loci; D3-D7 (chr2, chr5, chr4, chr3 at 5.6 Mb, chr1; |delta| 0.39-0.47) are weaker chance peaks in 20-line pools and have no Gw region.
        expected_output/loci_comparison.csv         one row per locus: span, peak, how many window sizes found it, length and p-value at each size
        expected_output/significant_regions.csv     one row per region and window size: left / peak / right marker, genotype classes at the peak, pattern, adjusted p-value
        expected_output/window_comparison.csv       the three window sizes side by side (threshold, windows tested, regions)
        expected_output/marker_statistics.csv       G1, G2, Gw, SNP_index_high, SNP_index_low, Delta_SNP_index and the window values of every marker
        expected_output/snp_index_regions.csv, snp_index_track.csv   the dSNP-index peak regions and the sliding-window track with its 95 % / 99 % intervals
        expected_output/InSilico_BSA.xlsx           all tables; InSilico_BSA_all_files.zip holds everything
        expected_output/*.png                       snp_index_tracks, gw_windows_compared, loci_compared, methods_compared, genotypes_at_peaks, pools, permutation_null

NOTE    The permutations use a fixed seed, so the thresholds repeat. In a RIL population (no heterozygous lines) Gw equals G1; use an F2 population to see over-dominant loci. A very polygenic trait gives
        many regions. Method: Li et al. 2022, Plant Communications 3:100319 (dQTG-seq).
