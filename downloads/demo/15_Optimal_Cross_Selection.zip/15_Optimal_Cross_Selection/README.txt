OPTIMAL CROSS SELECTION - which crosses to make: the highest usefulness, balanced against diversity  (run time about 10 s)

INPUT   input/dosage_matrix.csv    the 60 lines x 315 SNP allele dosage matrix (0 / 1 / 2). REAL genotypes: the 60 most different lines of the mapping population (chosen by maximum distance).
        input/marker_effects.csv   Marker, Effect: additive effect of each SNP. SIMULATED trait: ridge regression of the Yield of demo 04 on the dosages of the 100 lines.
        input/genetic_map.csv      Marker, Chromosome, cM. REAL map: the positions the Linkage Mapping demo (03) calculated for these markers.
        input/markers.vcf          the same SNPs as a VCF (their real physical positions), for the case WITHOUT a genetic map.
        There is no relationship matrix to prepare: it is calculated from the dosage matrix (VanRaden).

STEPS   Genomic Selection > Optimal Cross Selection > the three files > Preview & Validate (60 genotypes x 315 markers on 12 chromosomes; 607 heterozygous calls are read as missing).
        Population: Doubled haploids, generation 1, selected proportion 0.05, candidate pool 60.  Crosses 20, max per parent 4, penalty 30.  > Run.
        No genetic map? Choose "No map: use a VCF", select input/markers.vcf and enter a recombination rate of 4.3 cM per Mb (the real map has 1,620 cM on 373 Mb): the plan of crosses is similar
        (the usefulness values differ a little, because one rate for the whole genome is an approximation); a genetic map from Linkage Mapping is more accurate.

EXPECT  For every one of the 1,770 crosses among the 60 lines the tool calculates the mean of the progeny, its standard deviation (from the marker effects and the recombination along the map) and the
        usefulness = mean + selection intensity x standard deviation (average of all crosses 4.50, best cross MP058 x MP077 7.02).  The plan of 20 crosses uses 24 parents and has a mean usefulness of 6.31
        at a group coancestry of 0.091 and a progeny inbreeding of 0.0002; truncation selection gives 6.17 at a coancestry of 0.164 and an inbreeding of 0.066. Move the penalty toward 0 degrees for a higher
        usefulness and fewer parents (0 degrees: 6.57 with 12 parents).
        The values are on a relative scale (marker effects carry no intercept): only the differences between crosses matter.
        Outputs: the crossing plan, the contribution of every parent, the usefulness / diversity table and plot for every penalty degree, the usefulness of all crosses (ocs_all_crosses.csv) and the
        relationship matrix that was calculated (ocs_relationship_matrix.csv).
