PHENOTYPIC DATA ANALYSIS - field trial in three environments  (run time about 20 s)

INPUT   input/phenotypic_trial.csv   180 plots: Genotype, Environment, Rep, Block, Yield, Plant_Height, Days_to_Flowering.
        40 new entries (G001-G040) + 4 checks, augmented design with 5 blocks, 3 environments (Dry_2024, Wet_2024, Dry_2025). SIMULATED.

STEPS   Data Analysis > Phenotypic Data Analysis > Browse: phenotypic_trial.csv
        Traits: Yield, Plant_Height, Days_to_Flowering (all three).  Design: Augmented.  Clusters: 3, k-means.  > Run Full Analysis.

EXPECT  Descriptive statistics: mean yield Dry_2024 42.2, Dry_2025 47.3, Wet_2024 51.1 - the dry environments yield less.
        Heritability (Heritability tab), broad-sense on a plot basis / on an entry-mean basis:
              Yield 0.52 / 0.76     Plant_Height 0.50 / 0.75     Days_to_Flowering 0.22 / 0.45
        Design Check: 5 blocks, 4 repeated checks, 40 single entries per environment.  PCA, Clustering and Stability tabs fill with plots.
        (The values come from simulated data; yours should match to the printed digits.)
