GENES EXTRACTION - genes inside QTL intervals or around GWAS markers  (run time 1-2 s)

INPUT   input/qtl_intervals.csv   two QTL intervals (chr1, chr5) from QTL Mapping.   input/gwas_mtas.csv   marker-trait associations from GWAS.
        input/annotation_IRGSP1_regions.gff3   real rice genes (IRGSP-1.0, Ensembl Plants) of the three regions of interest.

STEPS   Trait Mapping > Genes Extraction > regions: qtl_intervals.csv, annotation: the GFF3, overlap, window 100 kb > Run.   Then repeat with gwas_mtas.csv.

EXPECT  QTL intervals: 22 genes (position, strand, biotype, description) and a gene ID list for Gene Prioritization.
        GWAS markers (each SNP widened by 100 kb on both sides): 102 genes; each gene is listed once in the ID list.
