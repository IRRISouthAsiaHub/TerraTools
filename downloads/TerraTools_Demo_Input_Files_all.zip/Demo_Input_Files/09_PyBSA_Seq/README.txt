PyBSA-Seq - bulked segregant analysis with the G statistic  (run time about 2 minutes with 500 simulation replicates)

INPUT   input/pybsa_parents.tsv  and  input/pybsa_bulks.tsv   GATK4 VariantsToTable tables (CHROM, POS, REF, ALT, QUAL and <sample>.GT/.AD/.GQ):
        parents Parent1 / Parent2 (homozygous, different) and bulks HighBulk / LowBulk; 3,731 variants, one every ~100 kb along the 12 rice chromosomes.
        The bulks are the 20 tallest and 20 shortest lines of the mapping population (PH of the mapping population, QTL on chr1 at 38.6 Mb; the former QTL Mapping demo, demo 04 now holds the GSTP009 blast data); the allele of every SNP comes from the REAL
        marker genotypes of the neighbouring markers, the read counts (about 40 x, 1 % errors) are SIMULATED.

STEPS   Trait Mapping > PYBSA G-statistics > Parents file: pybsa_parents.tsv, Bulks file: pybsa_bulks.tsv.
        Bulk sizes 20,20   Population RIL   p-values 0.01,0.01   Replication 500 (default 10000)   Sliding window 2000000,10000   Smoothing 51,3
        Read length 100   Region -1 (all)   Misc 20,5,1   Parent reference: no.  > Run Analysis.

EXPECT  An HTML report and figures (expected_output/PyBSASeq.png, PyBSASeq_report.html, sv_region.csv, significant_sv_regions.png).  In the four-panel figure the G statistic and the delta allele
        frequency leave their simulated 99 % thresholds on chromosome 1 (peak at about 35 Mb, G about 68, delta AF about -0.83) - the plant-height locus with SD1 - and on chromosome 9 (first 10 Mb,
        G about 25, delta AF about -0.5); chr3 (~17 Mb), chr4 (~29 Mb) and chr11 (~22 Mb) reach only G 14-16 near the limits
        (the tool's sign convention makes delta AF negative at the chr1 peak).  The sSV/totalSV panel is very sensitive and marks many weak regions (sv_region.csv); use G and delta AF.
