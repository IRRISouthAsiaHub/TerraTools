PHENOTYPIC DATA ANALYSIS - augmented field trial in three environments  (run time about 5-30 s per analysis)

INPUT   input/phenotypic_trial.csv   180 plots: Genotype, Environment, Rep, Block, Yield, Plant_Height, Days_to_Flowering.
        40 entries of the rice mapping population (MP001-MP100, spread over the whole yield range) + 4 rice checks (Check_IR64, Check_Swarna, Check_Sahbhagi,
        Check_Nipponbare), augmented design with 5 blocks, 3 environments (Dry_2024, Wet_2024, Dry_2025).
        The entries are lines of the real mapping population of the other demos; the FIELD DATA ARE SIMULATED: the genetic value of every entry is its Yield /
        Plant_Height of the QTL Mapping demo (04), plus environment, block and plot effects, so the trial and the QTL map describe the same plants.

STEPS   Data Analysis > Phenotypic Data Analysis > Data & Design > Browse: phenotypic_trial.csv  (design: Augmented RCBD is picked from the Block column).
        Analyses tab: pick an analysis, keep all three traits ticked, press its Run button. Each analysis runs on its own (about 5-30 s each);
        run Descriptives, Heritability, BLUPs, ANOVA, PCA, Clustering (3 clusters, k-means) and Stability & GxE (trait Yield) to fill the tabs.

EXPECT  Descriptive statistics: mean yield Dry_2024 41.7, Dry_2025 46.3, Wet_2024 50.2 - the dry environments yield less.
        Heritability (pooled over environments), on a plot basis / on an entry-mean basis:
              Yield 0.73 / 0.89     Plant_Height 0.65 / 0.85     Days_to_Flowering 0.54 / 0.78
        BLUPs (Yield, pooled over environments): 40 entries, H2 Cullis 0.88, mean reliability 0.86; best entry MP030 (BLUP +8.09, SE 1.55, predicted yield 54.4), then MP008 (+7.37)
              and MP071 (+6.34). Downloads > BLUPs (.xlsx) gives the BLUP table and the variance/heritability table. The 4 checks are fixed effects and have no BLUP.
        ANOVA (pooled): genotypes (adjusted for blocks) are significant for every trait, P < 0.001 (Yield F 8.8, Plant_Height F 7.5, Days_to_Flowering F 4.0); the environments differ too.
        Correlation: the three traits are only weakly correlated (r -0.04 to 0.24, none significant).
        Design Check: 5 blocks, 4 repeated checks, 40 single entries per environment.  PCA, Clustering and Stability tabs fill with plots.
        expected_output/ holds every table (CSV), the main figures (PNG) and the Excel workbooks (Phenotypic_Analysis.xlsx, ANOVA_tables.xlsx, BLUPs.xlsx).
        (The values come from simulated field data; yours should match to the printed digits.)
