BREEDSIGHT - genomic prediction with a neural network + random forest, compared with Lasso, RBLUP and GBLUP  (run time about 75 s with the demo settings)

INPUT   input/bs_train_phenotype.csv  (sample_id, phenotypes)  and  bs_train_genotype.csv (sample_id + 288 SNPs): 140 lines.
        input/bs_test_phenotype.csv  and  bs_test_genotype.csv: 36 lines.  REAL genotypes, SIMULATED trait (20 QTL, h2 0.8).
        The trait is given as a deviation from the mean (about 0): BreedSight does not rescale the trait, so a trait with a large mean (e.g. 5000 kg/ha) needs centring first.

STEPS   Genomic Selection > BreedSight GUI > the four files.   Cross-validation folds 3, heritability 0.8, epochs 100, batch 32, learning rate 0.001, weight 0.5,
        L2 0.01, dropout 0.3, RF trees 100, depth 15, PCA on (50 components), feature selection on (100).  (Defaults are 5 folds, 300 epochs, 200 trees.)  > Run.

EXPECT  Validation R2 / correlation:  RBLUP 0.53 / 0.75,  Lasso 0.41 / 0.67,  GBLUP 0.40 / 0.70,  BreedSight 0.39 / 0.69.   Every model predicts clearly better than chance.
        BreedSight fits its training data very closely (training r 0.98) but generalises like the linear models; RBLUP is best here because the trait is additive.
        Test Predictions: for each of the 36 test lines, the prediction of every model next to the true phenotype.  (The neural network is random: results vary by about +-0.03.)
