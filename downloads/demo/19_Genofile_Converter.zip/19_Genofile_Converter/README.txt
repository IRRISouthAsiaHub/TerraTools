GENOFILE CONVERTER - the start of the chain: genotyping-company files -> one coded 0/1/2 genotype table for the other analyses   (run time: about 1 s)

INPUT   The same 625 markers x 100 rice RILs (+ the two parents P1 and P2; the mapping population) of the 1K RiCA SNP panel, delivered the four ways a genotyping company sends them. Any one of them gives the same result:
        input/genotypes_hapmap.hmp.txt   HapMap: rs#, alleles, chrom, pos, strand ... QCcode, then one column per sample (calls AA, AG, GG, NN)
        input/genotypes.vcf              VCF: #CHROM POS ID REF ALT ... FORMAT, GT of every sample (0/0, 0/1, 1/1, ./.)
        input/genotypes.vcf.gz           the same VCF, gzipped
        input/raw_allele_calls.csv       raw sheet: Marker, Chromosome, P1, P2, then one column per RIL, calls like C:G ("-" = no call). The REAL sheet of the panel: many of its markers carry no information.

STEPS   Data Analysis > Genofile Converter > Browse: genotypes.vcf.gz (the format is detected).
        Parents and samples: Parent 1 = P1, Parent 2 = P2 (found automatically).  Output settings: defaults (marker names as in the file, chromosome numbers).  > Convert Genotype File.
        Then download the coded CSV / Excel file, or continue with it in another tool with the buttons under "Your converted file".
        For the raw CSV: Browse raw_allele_calls.csv, check the column roles (Marker, Chromosome, P1, P2) and the separator (colon), Convert.

EXPECT  625 markers read, 310 coded, 315 left out (41 with an invalid / missing parent call, 274 with the same allele in both parents); 100 individuals; 1.2 % of the calls missing / unexpected;
        code counts 0: 17,100   1: 99   2: 13,430   -1: 371.  12 chromosomes.  All four input files give exactly the same table.
        expected_output/genotypes_coded.csv    the coded table: Marker, Chromosome, then one column per individual (0 = P1 allele, 1 = heterozygous, 2 = P2 allele, -1 = missing / unexpected);
                                               identical to 02_Mendelian_Segregation/input/coded_genotypes_RIL.csv
        expected_output/genotypes_coded.xlsx   the same table on the first sheet, then Marker_Details, Excluded_Markers (the 315 markers and why) and Summary
        Marker names such as chr01_1044946 carry the physical position, which analyses such as Linkage Mapping use to check the marker order.
