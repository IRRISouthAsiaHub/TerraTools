# TerraTools demo input files

Small, purpose-built inputs for all 21 tools - **all of them rice**. Each folder holds `input/` (the files to load), `expected_output/` (what the tool produced when we ran it, so you can compare)
and `README.txt` (the exact settings to enter, the run time and the numbers you should see).

| # | Tool | Run time* | Headline result |
|---|------|-----------|-----------------|
| 01 | Phenotypic Data Analysis | 5-30 s per analysis | Grain-yield heritability 0.69 (plot) / 0.87 (entry mean); Wet_2024 yields most; best entry IR127304-1153 |
| 02 | Mendelian Segregation | 10 s | 93 of 310 markers distorted after FDR correction at alpha 0.10 (chr12 most), 217 kept |
| 03 | Linkage Mapping | 1 min | 300 SNPs of the 356 GSTP009 inbred lines: only 126 stay on a map of 11 chromosomes (chr9 lost), and the order does not follow the genome - unrelated lines are not a mapping population (the README explains) |
| 04 | QTL Mapping | 20 s per run | Real data of 356 rice inbred lines (blast resistance, GSTP009 data): CIM with a permutation threshold finds 4 QTL (chr3, chr4 LOD 7.3, chr9, chr12), MQM 10; SIM at a fixed LOD 3 calls 292 because of the population structure |
| 05 | QTL-Seq | 30 s | The plant-height locus on chr1 (30.9-41.2 Mb, peak 36.5 Mb, SD1 inside) at the 99 % level, plus a weaker chr9 region |
| 06 | Diversity Analysis | 10 s | The 5 clusters equal the 5 real rice sub-populations (aus, indica 2, temperate / tropical japonica, aromatic) |
| 07 | GWAS | 1 min | Blast resistance, 356 lines x 5,000 SNPs, three input routes (ready file, VCF + trait table, 3K panel): OLS 1,897 SNPs (lambda 26, structure) / MLM 0 / FarmCPU 5 (chr7 29.6 Mb, p 5e-11) |
| 08 | ET-GWAS | 5 s | Two MTAs: the planted common SNP (chr3) and the planted rare SNP (chr8) |
| 09 | PyBSA-Seq | 1-3 min | G statistic and delta AF leave the 99 % thresholds at the chr1 plant-height locus (G about 68) and on chr9 |
| 10 | Genes Extraction | 2 s | 98 genes in the four blast QTL regions of demo 04 (chr3 39, chr4 23 with two Pi63 genes, chr9 15, chr12 21), default settings |
| 11 | Gene Prioritization | about 1 min (needs internet) | The two Pi63 genes of the chr4 blast QTL rank first (72 and 61, "Direct association"); 12 of 16 candidates have no trait evidence |
| 12 | Clustering & Genomic Selection | 5 s | 5 clusters; 80 train / 20 test |
| 13 | Additive Dominance | 10 s | 100 x 100 additive and dominance matrices |
| 14 | BreedSight | 2-4 min | Amylose content of rice inbred lines (GSTP009 data, values as in the source sheet; training lines below 10 removed): 283 training / 74 testing, 50,000 SNPs: BreedSight R2 0.56 / r 0.76 in 2-fold cross-validation (0.59 / 0.77 on the testing lines) vs RBLUP 0.53, Lasso 0.52, GBLUP 0.48 |
| 15 | Optimal Cross Selection | 20 s | Amylose content (GSTP009 data), 370 phenotyped + 8 genotyped-only lines, 1,500 SNPs, pseudo map (heritability 0.76, accuracy 0.72); MPV and usefulness of 1,770 crosses; plan of 20 crosses, 20 parents |
| 16 | Heterosis | 2-3 min | Cross-validation r 0.47 for plant height; top hybrid IR127304-1162 x IR127304-1042 |
| 17 | Genotype Viewer | 5 s | 12 chromosomes drawn for 12 rice RILs, 286 markers; same picture from the CSV and the VCF |
| 18 | Favourable Allele Analysis | 1 s + 5 s | 327 / 327 trait-gene markers matched in a 1,027-marker rice 4K file (24 lines); balloon heatmap of 12 genes |
| 19 | Genofile Converter | 1 s | HapMap, VCF or raw allele files of the 1K RiCA panel become one coded 0/1/2 table (the input of tool 02): 625 markers read, 310 coded, 315 left out |
| 20 | Recombination Analysis | 5 s | 1,556 crossovers in 100 real RILs (mean 15.6 per line); mean donor content 45 % |
| 21 | In silico BSA | 10 s | Blast resistance, 356 lines x 4,000 SNPs, 71 + 71 line pools: 13 wide loci found by all three window sizes, covering most of the genome (population structure; the README explains) |

\* Measured on the development PC with the settings in each README (some use fewer simulation replicates, epochs or folds than the defaults to stay short).

**One mapping population.** Tools 01, 02, 05, 09, 12, 13, 16, 17, 19 and 20 are built on the same 100 real rice recombinant inbred lines (RILs) of the IRRI South Asia Hub, named IR127304-1002 ... IR127304-1280,
genotyped with the 1K RiCA SNP panel: 310 informative markers on 12 chromosomes, parent 1 = 0, heterozygous = 1, parent 2 = 2 (the real raw company files of tool 19 give exactly this table). The lines are the best
100 of 149 phenotyped lines (few missing calls, normal crossover numbers, no near-duplicates) and their ids are shifted from the originals. **Genotypes and traits are real** (19 traits); only what cannot exist
in this population is derived from the real calls: the sequencing reads of the bulks (tools 05, 09) and the field part of the augmented trial (tool 01); each README says so. The reference trait is plant height (PH),
the trait with the most QTL (chr1 next to the green-revolution gene SD1, chr2, chr4): it runs through heterosis and the two bulked-segregant tools 05 and 09; grain yield (GYKGHA) through the phenotypic trial.
The QTL Mapping, Linkage Mapping, GWAS, Optimal Cross Selection and In silico BSA demos used to be built on this population too and now use the GSTP009 data (below); the former files of this population remain
the source of the other tools.

**Diversity-panel demos.** Tools 06 and 08 use real genotypes of the rice 3K panel that ships with TerraTools (sub-populations aus, indica 2, japonica, aromatic); tool 18 uses a rice 4K haplopanel file of 24
improved varieties and landraces. Results of the neural-network tools (BreedSight, Heterosis) vary a little between runs.

**GSTP009 demos (03, 04, 07, 10, 11, 14, 15, 21).** These tools use a different data set: rice inbred lines of the GSTP009 data (5.2 million SNPs). Demos 03, 04, 07, 10, 11 and 21 use the 356 lines with a
blast-resistance score (0 to 9); demos 14 and 15 use the lines with an amylose-content value (sheet "breedsight" of GSTP009.xlsx: 370 lines; in demo 14 13 low training lines are removed). Phenotype values are copied unchanged.
It is a diversity panel with strong population structure and no mapping family, so the READMEs say how to read the numbers - for Linkage Mapping (03) and In silico BSA (21), which are made for populations from a cross, the
results mainly show the structure of the panel. Ids are those of the source files.
The CIM QTL table of demo 04 leads to the 98 genes of demo 10 (real IRGSP-1.0 genes of the four regions) and to the ranking of 16 of them in demo 11 (live public databases, so its scores can drift slightly).
They are made by `docs/make_gstp009_inputs.py` (04, 14), `make_gstp009_linkage.py` (03), `make_gstp009_gwas.py` (07), `make_gstp009_ocs.py` (15), `make_gstp009_bsa.py` (21), `make_blast_genes_demo.py` (10) and `run_blast_prioritization.py` (11).

The inputs are made by `docs/make_rice_demos.py` (and its `rice_stage_*.py` files) and the outputs by `docs/run_rice_demos.py`, with fixed seeds, from the source files in `docs/demo_source`.
