OPTIMAL CROSS SELECTION - which crosses to make, balancing gain against diversity  (run time about 8 s)

INPUT   input/ocs_criterion.csv   60 candidate lines with a selection criterion (a breeding value).   input/ocs_kinship.csv   their 60 x 60 kinship matrix (VanRaden).
        REAL genotypes, SIMULATED breeding values.

STEPS   Genomic Selection > Optimal Cross Selection > the two files > Preview & Validate (60 lines match).   Crosses 20, max crosses per parent 4, penalty degree 30.  > Run.

EXPECT  An optimal plan of 20 crosses using 12 parents, expected gain 5.00, group coancestry 0.096, progeny inbreeding 0.
        For comparison, truncation selection (mate the best lines) would give a gain of 7.21 but a coancestry of 0.21 and a progeny inbreeding of 0.17.
        The frontier plot and the table show the gain against diversity for every penalty degree - move the penalty to choose another compromise.
