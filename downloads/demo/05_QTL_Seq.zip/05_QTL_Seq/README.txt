QTL-SEQ - bulked segregant analysis from a VCF  (run time about 30 s with 1000 simulation replicates)

INPUT   input/qtlseq_bulks.vcf   one joint VCF with four samples (Parent1, Parent2, HighBulk, LowBulk): 3,731 SNPs, one every ~100 kb along the 12 rice chromosomes.
        The two bulks are the 20 tallest and the 20 shortest lines of the mapping population (Plant_Height of the QTL Mapping demo, planted QTL on chr3 at 11.6 Mb and chr8 at 9.4 Mb).
        The allele of every SNP in every line is taken from the REAL marker genotypes of the neighbouring markers; the sequencing reads (about 40 x per bulk, 1 % errors) are SIMULATED.

STEPS   Trait Mapping > QTL-Seq > Input: VCF files.  Choose qtlseq_bulks.vcf for high bulk, low bulk and parental VCF (the same file three times).
        Plants per bulk: 20 and 20, population RIL, index parent: parent 2.  Settings tab: simulation replicates 1000 (default 10000); call a QTL where the window mean passes the 99 % level.
        Turn on "advanced settings" and type the sample names: HighBulk, LowBulk, Parent1, Parent2.  > Run QTL-seq.

EXPECT  3,731 informative SNPs, 3,649 retained after the filters (82 removed by the SNP-index filter); two significant QTL at the 99 % level, both enriched in the high bulk:
        chr3 8.23-13.45 Mb, peak 11.13 Mb, peak delta SNP-index 0.74 (planted at 11.64 Mb);   chr8 4.86-23.83 Mb, peak 12.08 Mb, peak delta 0.94 (planted at 9.40 Mb).
        The chr8 interval is wide because the real RILs carry long unrecombined blocks there. At the default 90 % level a dozen weak regions appear as well: use 99 %.
