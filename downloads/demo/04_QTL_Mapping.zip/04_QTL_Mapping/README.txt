QTL MAPPING - BLAST RESISTANCE IN 356 RICE INBRED LINES (GSTP009)  (run time about 20 s per CIM / MQM run)

DATA    356 rice inbred lines with a blast-resistance score, genotyped with 5.2 million SNPs (PLINK files 378Rice_Inbred.bed/.bim/.fam, 378 lines;
        GSTP009.pheno.csv holds the trait of 357 lines, one of them without a value and left out). Line ids are the ones of the source files.

INPUT   input/genotypes_QTL_format.csv   the QTL Mapping format: row 1 marker names, row 2 chromosome, row 3 position (cM), then one row per line with the calls.
        input/phenotypes.csv             Line, Blast_resistance (a score from 0 to 9: 0 x2, 1 x67, 2 x22, 3 x33, 4 x31, 5 x24, 6 x37, 7 x33, 8 x52, 9 x55;
                                         mean 5.2, SD 2.9). The direction of the scale (is 9 resistant or susceptible?) is not stated in the source file.

WHAT WAS DONE TO THE RAW FILES
        1. 5,231,433 SNPs (IRGSP-1.0 positions, 12 chromosomes) were reduced to 1,249 markers: the SNP with the highest minor allele frequency in every 300 kb
           window (minor allele frequency at least 0.10, missing at most 2 %, heterozygous calls at most 5 %). Per chromosome: 145, 120, 122, 119, 100, 105, 99, 95, 77, 78, 97, 92.
        2. Calls are coded as copies of the MINOR allele: 0 = homozygous major, 1 = heterozygous (0.7 % of calls), 2 = homozygous minor. The panel has no missing calls.
        3. Marker names are chrNN_bp (for example chr04_31557420), so Genes Extraction can read the physical position from the name.
        4. These are unrelated inbred lines, not a mapping family, so there is no real genetic map. The position row is a PSEUDO map, base pairs / 1,000,000 x 4.3 cM
           (the rice average): it only gives the tool an ordered map. Distances in cM in the results are therefore not real recombination distances.

STEPS   Trait Mapping > QTL Mapping > the genotype file, the phenotype file, trait Blast_resistance > method CIM > threshold: permutation test (1,000) > Run.

EXPECT  CIM, permutation threshold LOD 4.04: 4 QTL.
            QTL_3.1   chr3   peak chr03_10319943   LOD 5.1
            QTL_4.1   chr4   peak chr04_31557420   LOD 7.3   (largest)
            QTL_9.1   chr9   peak chr09_5143688    LOD 4.5
            QTL_12.1  chr12  peak chr12_12670588   LOD 4.1
        MQM, threshold LOD 4.20: 10 QTL, including the four above (chr12 at 10.2 Mb) and regions on chromosomes 1, 5, 7 (three peaks) and 8.
        expected_output holds the tables, full scans and plots of CIM, MQM and of SIM.

HONEST NOTES
        - This is a diversity panel with strong population structure: the first principal component explains 34 % of the genotype variance, the second 12 %, and the
          blast score is correlated with both (r = -0.32 and -0.43). QTL Mapping has no kinship or structure correction. Use the PERMUTATION threshold: simple interval
          mapping (SIM) at a fixed LOD of 3 calls 292 "QTL" across the whole genome, which is the structure, not 292 loci (the SIM files in expected_output show this).
        - The QTL listed are therefore candidate regions of an association scan, not mapped loci; confirm them with GWAS (MLM or FarmCPU) before you rely on them.
        - The map is a pseudo map (see above); the percentage of variance explained of the CIM peaks varies a lot between markers (QTL_12.1 shows 0.3 % at its marker).
        - The score is ordinal (0-9); the tool treats it as a continuous trait.
