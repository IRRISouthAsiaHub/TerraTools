# TerraTools demo input files

Small, purpose-built inputs for all 21 tools - **all of them rice**. Each folder holds `input/` (the files to load), `expected_output/` (what the tool produced when we ran it, so you can compare)
and `README.txt` (the exact settings to enter, the run time and the numbers you should see).

| # | Tool | Run time* | Headline result |
|---|------|-----------|-----------------|
| 01 | Phenotypic Data Analysis | 5-30 s per analysis | Grain-yield heritability 0.69 (plot) / 0.87 (entry mean); Wet_2024 yields most; best entry IR127304-1153 |
| 02 | Mendelian Segregation | 10 s | 93 of 310 markers distorted after FDR correction at alpha 0.10 (chr12 most), 217 kept |
| 03 | Linkage Mapping | 30 s | 286 of 310 markers mapped, 12 chromosomes, about 2,082 cM |
| 04 | QTL Mapping | 10-30 s per run | Real traits: plant height (PH) gives three QTL by CIM / MQM (chr1 LOD 15.8 next to SD1, chr2, chr4), SIM at LOD 3 two; a control trait gives none |
| 05 | QTL-Seq | 30 s | The plant-height locus on chr1 (30.9-41.2 Mb, peak 36.5 Mb, SD1 inside) at the 99 % level, plus a weaker chr9 region |
| 06 | Diversity Analysis | 10 s | The 5 clusters equal the 5 real rice sub-populations (aus, indica 2, temperate / tropical japonica, aromatic) |
| 07 | GWAS | 15 s | OLS 4 / MLM 3 / FarmCPU 3 significant SNPs; FarmCPU finds all three plant-height QTL (chr1, chr4, chr2) |
| 08 | ET-GWAS | 5 s | Two MTAs: the planted common SNP (chr3) and the planted rare SNP (chr8) |
| 09 | PyBSA-Seq | 1-3 min | G statistic and delta AF leave the 99 % thresholds at the chr1 plant-height locus (G about 68) and on chr9 |
| 10 | Genes Extraction | 2 s | 565 genes in the three plant-height QTL regions (chr1 36.5-38.8 Mb with SD1, chr2, chr4) |
| 11 | Gene Prioritization | about 3 min (needs internet) | 6 known plant-height genes score 40-72 ("Direct association"), 2 controls score 0-15 |
| 12 | Clustering & Genomic Selection | 5 s | 5 clusters; 80 train / 20 test |
| 13 | Additive Dominance | 10 s | 100 x 100 additive and dominance matrices |
| 14 | BreedSight | 1-2 min | Real data of the Rice Diversity Panel 1 (seed width, 377 accessions, source in its README): BreedSight R2 0.57 / r 0.76 beats GBLUP 0.41, RBLUP 0.38 and Lasso 0.38 |
| 15 | Optimal Cross Selection | 20 s | Marker effects estimated from 80 phenotyped lines (grain yield, accuracy 0.30); MPV and usefulness of 1,770 crosses; plan of 20 crosses, 20 parents, far lower coancestry than truncation selection |
| 16 | Heterosis | 2-3 min | Cross-validation r 0.47 for plant height; top hybrid IR127304-1162 x IR127304-1042 |
| 17 | Genotype Viewer | 5 s | 12 chromosomes drawn for 12 rice RILs, 286 markers; same picture from the CSV and the VCF |
| 18 | Favourable Allele Analysis | 1 s + 5 s | 327 / 327 trait-gene markers matched in a 1,027-marker rice 4K file (24 lines); balloon heatmap of 12 genes |
| 19 | Genofile Converter | 1 s | HapMap, VCF or raw allele files of the 1K RiCA panel become one coded 0/1/2 table (used by tools 02 and 03): 625 markers read, 310 coded, 315 left out |
| 20 | Recombination Analysis | 5 s | 1,556 crossovers in 100 real RILs (mean 15.6 per line); mean donor content 45 % |
| 21 | In silico BSA | 10 s | 1 locus (chr1, peak 37.5 Mb) found by all three window sizes |

\* Measured on the development PC with the settings in each README (some use fewer simulation replicates, epochs or folds than the defaults to stay short).

**One mapping population.** Tools 01-05, 07, 09, 10, 12, 13, 15-17, 19-21 are built on the same 100 real rice recombinant inbred lines (RILs) of the IRRI South Asia Hub, named IR127304-1002 ... IR127304-1280,
genotyped with the 1K RiCA SNP panel: 310 informative markers on 12 chromosomes, parent 1 = 0, heterozygous = 1, parent 2 = 2 (the real raw company files of tool 19 give exactly this table). The lines are the best
100 of 149 phenotyped lines (few missing calls, normal crossover numbers, no near-duplicates) and their ids are shifted from the originals. **Genotypes and traits are real** (19 traits); only what cannot exist
in this population is derived from the real calls: the sequencing reads of the bulks (tools 05, 09, 21) and the field part of the augmented trial (tool 01); each README says so. The reference trait is plant height (PH),
the trait with the most QTL (chr1 next to the green-revolution gene SD1, chr2, chr4): it runs through QTL mapping, GWAS, genes extraction, heterosis and the three bulked-segregant tools; grain yield (GYKGHA)
through the phenotypic trial and optimal cross selection.

**Diversity-panel demos.** Tools 06 and 08 use real genotypes of the rice 3K panel that ships with TerraTools (sub-populations aus, indica 2, japonica, aromatic); tool 14 uses the public Rice Diversity Panel 1
(real genotypes and a real trait); tool 18 uses a rice 4K haplopanel file of 24 improved varieties and landraces; tool 11 uses real rice genes and live public databases, so its scores can drift slightly.
Results of the neural-network tools (BreedSight, Heterosis) vary a little between runs.

The inputs are made by `docs/make_rice_demos.py` (and its `rice_stage_*.py` files) and the outputs by `docs/run_rice_demos.py`, with fixed seeds, from the source files in `docs/demo_source`.
