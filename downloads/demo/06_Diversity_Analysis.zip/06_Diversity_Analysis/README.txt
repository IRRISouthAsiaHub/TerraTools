DIVERSITY ANALYSIS - diversity indices of rice sub-populations from SNP/haplotype codes  (run time about 10 s)

INPUT   input/diversity_haplotype_blocks.csv   100 rice accessions (5 sub-populations x 20) x 150 genome-wide SNPs coded 0/1/2, about 1 % missing (-1). REAL genotypes of the rice 3K panel
        that ships with TerraTools: Aus, Indica_2, Temperate_japonica, Tropical_japonica and Aromatic (column 1 = sub-population, column 2 = accession ID, then the SNPs, named Chr_position).

STEPS   Trait Mapping > Diversity Analysis > Browse: diversity_haplotype_blocks.csv.   Clusters: 5, top blocks 25, normalised radar on.  > Run Full Analysis.

EXPECT  The 5 hierarchical clusters reproduce the 5 sub-populations exactly (20 accessions each), and so does the PCA.
        Mean Shannon diversity per group: Indica_2 0.79, Aus 0.77, Aromatic 0.71, Tropical_japonica 0.70, Temperate_japonica 0.69 (effective alleles 2.09, 2.04, 1.97, 1.99, 1.95): the indica / aus
        groups are the most diverse, the temperate japonica the least.  The Variety Comparison tab shows the gradient; the neighbour-joining tree separates five groups.
        results.csv has every metric for every sample.
