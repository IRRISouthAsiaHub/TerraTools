The chain from Genes Extraction: 22 genes of the two QTL (candidate_genes.txt) + the QTL intervals (qtl_intervals.csv) = 41 candidate genes.
Load the genes as the gene list and the intervals as the GWAS/QTL file, window 50 kb. It takes 10-14 minutes with a cold cache (waiting for the public servers).
