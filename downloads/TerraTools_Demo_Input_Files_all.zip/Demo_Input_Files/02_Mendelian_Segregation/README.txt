MENDELIAN SEGREGATION - find markers that do not follow the expected ratio  (run time about 10 s)

INPUT   input/coded_genotypes_RIL.csv   334 markers x 176 rice RILs (BSP2 population), coded 0/1/2: Marker, Chromosome, then one column per line. REAL genotypes.

STEPS   Trait Mapping > Mendelian Segregation > Browse: coded_genotypes_RIL.csv
        Population type: RIL (1:1).  Threshold p < 0.05.  Missing codes: NA, ., -9.  > Run Segregation Test.

EXPECT  334 markers tested; 104 distorted at p < 0.05, 230 kept in the filtered set (results_filtered.csv).
        Distorted markers per chromosome: chr1 25, chr3 17, chr6 23, chr7 12, chr12 12, chr8 6, chr10 6, chr5 2, chr2 1; none on chr4, chr9, chr11.
        manhattan.png: -log10(p) along the markers with the threshold line; rateplot.png: share of distorted markers per chromosome (highest on chr6, chr1, chr7; none on chr4, chr9, chr11).
