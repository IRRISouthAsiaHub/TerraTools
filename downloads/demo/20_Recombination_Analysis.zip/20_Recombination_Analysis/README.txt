RECOMBINATION ANALYSIS - crossovers, donor content and recombination along the chromosomes   (run time: about 5 s)

INPUT   input/mapping_population.csv   318 markers on 12 chromosomes (CHROM, POS, ID, REF, ALT, PARENT1_GT, then one _GT column per line): the REAL calls of the 100 rice RILs of the mapping population
        (markers whose name carries a physical position). Parent 1 is the recurrent parent, the donor content is the share of parent 2.

STEPS   Trait Mapping > Recombination Analysis > Browse: mapping_population.csv.  Recurrent parent: PARENT1 (found automatically), no donor.
        Settings: smoothing "Original script", minimum block 2 %, bin 5 Mb.  > Run Analysis.

EXPECT  318 of 318 markers informative; 1,502 crossovers in 100 lines (mean 15.0 per line, 10 to 22); mean donor content 51 % (32 % to 70 % per line), as expected for RILs of two parents.
        2.9 % of the calls are heterozygous and 0.09 % missing; the smoothing at a 2 % block changes 938 of the calls (short heterozygous or single-marker segments).
        The marker names carry no gene ID, so crossovers are not split into intragenic and intergenic (name the markers chr1_134521_LOC_Os01g01280 to get that part; see the Method Guide).
        expected_output/crossover_breakpoints.csv      every crossover: line, chromosome, flanking markers and positions, size, direction
        expected_output/per_RIL_summary.csv, per_chromosome_summary.csv, recombination_summary.csv, crossover_rate_by_bin.csv
        expected_output/Recombination_Analysis.xlsx    all tables in one workbook; Recombination_Analysis_all_files.zip holds everything
        expected_output/*.png                           crossovers per line, genome-wide rate, donor content, haplotype mosaic, circos plot
