HETEROSIS - predict hybrid performance from the parents with a neural network  (run time about 2-3 minutes with the demo settings)

INPUT   input/het_train_phenotype.csv (ID, Height_above_shortest_dm) and het_train_genotype.csv: 80 training lines x 278 SNPs.   input/het_parent_genotype.csv: 10 candidate parents.
        input/het_test_genotype.csv: 10 further lines to predict.  All 100 lines of the rice mapping population, REAL genotypes and a REAL trait: the plant height PH of every line expressed as the height above
        the shortest line in dm ((PH - minimum) / 10, about 0 to 4.4; the trait is kept near 0-4 on purpose: the network is not given a rescaled trait, see BreedSight).

STEPS   Genomic Selection > Heterosis > the four files.   F1 hybrids to report 5, parents 5, folds 3, epochs 250, batch 16, dropout 0.2, L1 0.001, L2 0.001.  > Run Prediction.
        (Defaults are 5 folds; the demo uses 3 so that it takes about two minutes.)

EXPECT  Cross-validation: Pearson r 0.47, R2 0.10, RMSE 0.96 - a modest but real predictive ability from 80 lines (folds r 0.46 / 0.37 / 0.58).  45 hybrids (10 parents) are scored.
        Top F1 hybrid IR127304-1162 x IR127304-1042, predicted 2.47, mid-parent heterosis +14.5 %; the next hybrids combine IR127304-1162, IR127304-1214 and IR127304-1135.  Mid-parent and best-parent
        heterosis are measured against the mean and the maximum of the TRAINING lines, so best-parent heterosis is negative (the best training line is better than any hybrid).  Top parents
        (IR127304-1162 2.26, IR127304-1214 2.25, IR127304-1042 2.22, IR127304-1135 2.18, IR127304-1280 2.15) and the test-line predictions are listed as well.  Neural-network results vary a little between runs.
