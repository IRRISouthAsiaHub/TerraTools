QTL MAPPING - SIM, CIM and MQM on three traits  (run time about 10-30 s per run, the permutation test included)

INPUT   input/genotypes_QTL_format.csv   the "QTL Mapping input" file of Linkage Mapping (demo 03): 334 markers on the 12-chromosome map x 100 rice RILs (REAL genotypes).
        input/phenotypes.csv   Line, Yield, Plant_Height, No_QTL_Trait - SIMULATED on those real genotypes: the QTL were planted at real markers, so the right answer is known.
        input/answer_key_planted_QTL.csv   Yield: chr1 chr01_20562598 (+1.6) and chr5 chr05_7328783 (+1.2) - the two places of the rice genome whose genes are in the Genes Extraction demo;
        Plant_Height: chr3 chr03_11644944 (+4.0) and chr8 chr08_9400516 (+2.8); No_QTL_Trait: none (the negative control).

STEPS   Trait Mapping > QTL Mapping > load the two files (genotypes and phenotypes).
        Run 1: trait Yield, SIM, fixed LOD 3.     Run 2: trait Yield, CIM, permutation test (1000 permutations, 5 %).     Run 3: trait Yield, MQM, permutation.
        Run 4: Plant_Height, CIM, permutation.   Run 5: No_QTL_Trait, CIM, permutation (the negative control).

EXPECT  Yield, SIM at LOD 3:  chr1 (chr01_20562598, LOD 10.9, 39 % of the variance) and chr5 (chr05_7328783, LOD 7.3, 29 %).
        Yield, CIM with the permutation threshold (LOD 3.59): the same two QTL, LOD 15.0 and 10.9.   Yield, MQM (threshold 3.58): the same two, LOD 15.0 and 10.9.
        Plant_Height, CIM (threshold 3.59): chr3 chr03_11644944 (LOD 13.0, 41 %) and chr8 chr08_9400516 (LOD 11.5, 37 %).   No_QTL_Trait, CIM (threshold 3.86): 0 QTL.
        Every model calls exactly the planted markers, and nothing else. The machine-learning models (Random Forest, SVR; ML scans with 40 permutations take about 3 minutes each) agree on all three traits: both call chr1 and chr5
        for Yield and chr3 and chr8 for Plant_Height at the planted markers, and nothing for No_QTL_Trait.
        expected_output/ holds, per run, the QTL table, the full scan, the Manhattan plot and the chromosome ideogram (the linkage-map-style picture with the QTL in red).
