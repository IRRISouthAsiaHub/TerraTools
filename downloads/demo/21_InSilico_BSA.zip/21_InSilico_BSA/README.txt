IN SILICO BSA - bulked segregant analysis from the genotype and trait of every line   (run time: about 10 s)

INPUT   input/genotypes_RIL.csv   4,000 SNPs on the 12 rice chromosomes (CHROM, POS, ID, then one column per line), 356 rice inbred lines (GSTP009 panel) coded 0 / 2 (copies of the first allele of the PLINK .bim file). One SNP
        every ~93 kb: evenly spaced from the SNPs with minor allele frequency >= 0.05 and no missing or heterozygous call in any line (933,761 SNPs). IRGSP-1.0 positions.
        input/phenotypes.csv     Sample, Blast_resistance (the blast score 0-9 of GSTP009.pheno.csv, values unchanged; the first column holds the line names exactly as in the genotype file).

STEPS   Trait Mapping > In silico BSA > Browse: genotypes_RIL.csv, then the phenotype file phenotypes.csv (trait Blast_resistance).
        Pools 20 % (71 + 71 lines), population type: RIL, primary window 1000 kb, window sizes 500 / 1000 / 2000 kb, merge regions closer than 2000 kb, 1000 permutations, level 0.05.  > Run Analysis.

EXPECT  Gw threshold 4.79 / 3.89 / 3.00 for the 500 kb / 1 Mb / 2 Mb windows: 25, 16 and 13 regions, 13 loci in all, every one found by all three window sizes. The regions are wide (median 8 - 28 Mb) and cover most of the
        genome: see the note. Strongest regions at 500 kb: chr10 18.7 Mb (LOD 11.7), chr5 20.0 Mb (LOD 10.0), chr6 4.3 Mb (9.6), chr1 4.2 Mb (9.4), chr4 32.7 Mb (9.0; the parent 1 allele goes with the high pool), chr7 29.2 Mb (8.5).
        The SNP-index view (snp_index_tracks.png, snp_index_regions.csv) lists 12 or more peak regions (dSNP-index up to +0.62 on chr7 at 29.6 Mb, -0.35 on chr4 at 33.2 Mb).
        Output files: loci_comparison.csv, significant_regions.csv, window_comparison.csv, marker_statistics.csv, snp_index_regions.csv, snp_index_track.csv, InSilico_BSA.xlsx (all tables), InSilico_BSA_all_files.zip and the figures
        (snp_index_tracks, gw_windows_compared, loci_compared, methods_compared, genotypes_at_peaks, pools, permutation_null).

NOTE    BSA is designed for a segregating population from two parents. These 356 lines are an unrelated diversity panel with strong population structure: the lines of the two pools differ in the ancestry of whole chromosomes,
        so almost every region is "significant" and the loci are wide; they are not mapped QTL. The demo shows how to run the tool and read its outputs. To look for blast-resistance loci in this panel use the QTL Mapping (04) and
        GWAS (07) demos, which correct for structure. Method: Li et al. 2022, Plant Communications 3:100319 (dQTG-seq).
