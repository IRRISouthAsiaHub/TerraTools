IN SILICO BSA - bulked segregant analysis from the genotype and trait of every line   (run time: about 10 s)

INPUT   input/genotypes_RIL.csv   3,731 SNPs on the 12 rice chromosomes (CHROM, POS, ID, then one column per line), 100 rice RILs coded 0 / 2 (0 = parent 1, 2 = parent 2). One SNP every ~100 kb: the allele
        of each SNP is taken from the REAL marker genotypes of the neighbouring markers of the mapping population (a crossover falls at a random place between two markers that differ).
        input/phenotypes.csv     Sample, PlantHeight (the first column holds the line names exactly as in the genotype file). The REAL plant height (PH) of the QTL Mapping demo 04.

STEPS   Trait Mapping > In silico BSA > Browse: genotypes_RIL.csv, then the phenotype file phenotypes.csv (trait PlantHeight).
        Pools 20 % (20 + 20 lines), population type: RIL, primary window 1000 kb, window sizes 500 / 1000 / 2000 kb, merge regions closer than 2000 kb, 1000 permutations, level 0.05.  > Run Analysis.

EXPECT  1 locus, found by all three window sizes; 1 significant region at every size. Gw threshold of the 500 kb windows 7.45 (1 Mb: 6.59, 2 Mb: 5.82). At the 1 Mb size:
        L1 chr1 33.06-39.94 Mb, peak 37.45 Mb (adjusted p 0.001, LOD 7.9, delta SNP-index +0.90): the SD1 region (38.38 Mb) and the main QTL of demo 04.
        SNP-index view (snp_index_tracks.png, the first figure; the SNP-index is the frequency of the parent 2 allele, dSNP-index = high pool - low pool, positive: the parent 2 allele goes with the taller
        plants): 7 peak regions outside the 99 % interval of the permutations (snp_index_regions.csv): D1 chr1 29.4-42.7 Mb (delta +0.87, peak chr1_37654222) is the main locus; D2 chr9 (delta +0.52,
        peak 10.5 Mb) and D3 chr11 (+0.52, 23.0 Mb) are weaker; D4 chr4 (peak 30.5 Mb, delta -0.44) and D5 chr2 (peak 0.04 Mb, delta -0.43) coincide with the chr4 and chr2 QTL of demo 04, with the
        parent 1 allele going with the taller plants; D6 (chr2) and D7 (chr3) are weak chance peaks in 20-line pools and have no Gw region.
        expected_output/loci_comparison.csv         one row per locus: span, peak, how many window sizes found it, length and p-value at each size
        expected_output/significant_regions.csv     one row per region and window size: left / peak / right marker, genotype classes at the peak, pattern, adjusted p-value
        expected_output/window_comparison.csv       the three window sizes side by side (threshold, windows tested, regions)
        expected_output/marker_statistics.csv       G1, G2, Gw, SNP_index_high, SNP_index_low, Delta_SNP_index and the window values of every marker
        expected_output/snp_index_regions.csv, snp_index_track.csv   the dSNP-index peak regions and the sliding-window track with its 95 % / 99 % intervals
        expected_output/InSilico_BSA.xlsx           all tables; InSilico_BSA_all_files.zip holds everything
        expected_output/*.png                       snp_index_tracks, gw_windows_compared, loci_compared, methods_compared, genotypes_at_peaks, pools, permutation_null

NOTE    The permutations use a fixed seed, so the thresholds repeat. In a RIL population (no heterozygous lines) Gw equals G1; use an F2 population to see over-dominant loci. A very polygenic trait gives
        many regions. Method: Li et al. 2022, Plant Communications 3:100319 (dQTG-seq).
