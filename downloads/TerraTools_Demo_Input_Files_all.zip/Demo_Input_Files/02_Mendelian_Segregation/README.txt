MENDELIAN SEGREGATION - find markers that do not follow the expected ratio  (run time about 10 s)

INPUT   input/coded_genotypes_RIL.csv   334 markers x 100 rice RILs (the mapping population MP001-MP100), coded 0/1/2: Marker, Chromosome, then one column per line. REAL genotypes
        (the table the Genofile Converter writes, demo 19).

STEPS   Trait Mapping > Mendelian Segregation > Browse: coded_genotypes_RIL.csv
        Population type: RIL (classes 0 and 2 in 1:1, exact binomial test).  Alpha 0.10 (a population of 100 lines has little power; at 0.05 FDR flags none).
        Correction: FDR (Benjamini-Hochberg, the default).  Missing codes: NA, ., -9, -1.  > Run Segregation Test.

EXPECT  334 markers tested, none inconclusive (every marker has far more than 6 calls). The 957 heterozygous calls of the RILs (2.9 %) are not part of the test and are listed in the summary.
        FDR, alpha 0.10 (expected_output):  10 flagged distorted, 324 pass the quality check (results_filtered.csv, markers_LMready.xlsx).
                         Distorted per chromosome: chr1 4, chr8 3, chr7 2, chr3 1.  The strongest markers are chr07_15340454 (68 : 31 lines, parent 1 in excess) and chr01_22554065 (31 : 67, parent 2 in excess).
        Bonferroni, alpha 0.10:   1 distorted (chr7), 333 pass.
        None (raw p, alpha 0.05): 55 distorted (chr1 12, chr12 11, chr3 10, chr7 5, chr4 5, chr8 4, chr6 3, chr2 2, chr5 2, chr11 1), 279 pass - uncorrected testing flags far more markers by chance.
        FDR, alpha 0.05:          0 distorted, all 334 pass.
        Three plots: manhattan.png (segregation plot): -log10(p) along the markers, one colour per chromosome, dashed line = cut-off of the correction; heterozygosity.png: % heterozygous calls per marker,
        same colours (about 3 % here, as expected in RILs); rateplot.png (distortion summary): % distorted markers per chromosome.
        markers_LMready.xlsx: the passing markers (Marker, Chromosome, genotypes), ready to load in Linkage Mapping.

OTHER POPULATIONS  Choose BC1P1 / BC1P2 (1:1), F2 (1:2:1), F3 (3:2:3) or F4 (7:2:7) for those generations: each has its own model, F1 is refused, and a marker with too few calls to reach alpha is
        reported as inconclusive (column call), neither distorted nor passed. A population that is mostly one parent on every chromosome (for example a backcross-derived set run as RIL) shows almost
        every marker distorted; choose a type that fits the generation or treat the test only as a quality check.
