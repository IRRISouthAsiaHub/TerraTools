# TerraTools demo input files

Small, purpose-built inputs for all 21 tools - **all of them rice**. Each folder holds `input/` (the files to load), `expected_output/` (what the tool produced when we ran it, so you can compare)
and `README.txt` (the exact settings to enter, the run time and the numbers you should see).

| # | Tool | Run time* | Headline result |
|---|------|-----------|-----------------|
| 01 | Phenotypic Data Analysis | 5-30 s per analysis | Yield heritability 0.73 (plot) / 0.89 (entry mean); Wet_2024 yields most; best entry MP030 |
| 02 | Mendelian Segregation | 10 s | 10 of 334 markers distorted after FDR correction at alpha 0.10 (55 uncorrected at 0.05), 324 kept |
| 03 | Linkage Mapping | 30 s | 334 markers mapped, 12 chromosomes, about 1,620 cM |
| 04 | QTL Mapping | 10-30 s per run | SIM, CIM and MQM (and Random Forest / SVR) find exactly the planted QTL: Yield chr1 + chr5, Plant_Height chr3 + chr8; the control trait gives none |
| 05 | QTL-Seq | 30 s | Two QTL at the 99 % level: chr3 (peak 11.1 Mb) and chr8 (peak 12.1 Mb) - planted at 11.6 and 9.4 Mb |
| 06 | Diversity Analysis | 10 s | The 5 clusters equal the 5 real rice sub-populations (aus, indica 2, temperate / tropical japonica, aromatic) |
| 07 | GWAS | 15 s | OLS 16 / MLM 2 / FarmCPU 2 significant SNPs; MLM and FarmCPU find exactly the two planted markers (chr1, chr5) |
| 08 | ET-GWAS | 5 s | Two MTAs: the planted common SNP (chr3) and the planted rare SNP (chr8) |
| 09 | PyBSA-Seq | 1-3 min | G statistic and delta AF leave the 99 % thresholds on chr3 and chr8, the two planted regions |
| 10 | Genes Extraction | 2 s | 94 genes in the two Yield QTL regions (chr1 20.2-20.8 Mb, chr5 7.0-7.5 Mb) |
| 11 | Gene Prioritization | about 3 min (needs internet) | 6 known yield genes score 49-62, 2 controls score 0 |
| 12 | Clustering & Genomic Selection | 5 s | 5 clusters; 80 train / 20 test |
| 13 | Additive Dominance | 10 s | 100 x 100 additive and dominance matrices |
| 14 | BreedSight | 1-2 min | Real data of the Rice Diversity Panel 1 (seed width, 377 accessions, source in its README): BreedSight R2 0.57 / r 0.76 beats GBLUP 0.41, RBLUP 0.38 and Lasso 0.38 |
| 15 | Optimal Cross Selection | 20 s | Marker effects estimated from 80 phenotyped lines (accuracy 0.64); MPV and usefulness of 1,770 crosses; plan of 20 crosses, 21 parents, far lower coancestry than truncation selection |
| 16 | Heterosis | 2 min | Cross-validation r 0.66; top hybrid MP009 x MP008 (mid-parent heterosis +27 %) |
| 17 | Genotype Viewer | 5 s | 12 chromosomes drawn for 12 rice RILs, 318 markers; same picture from the CSV and the VCF |
| 18 | Favourable Allele Analysis | 1 s + 5 s | 327 / 327 trait-gene markers matched in a 1,027-marker rice 4K file (24 lines); balloon heatmap of 12 genes |
| 19 | Genofile Converter | 1 s | HapMap, VCF or raw allele files become one coded 0/1/2 table (used by tools 02 and 03): 345 markers read, 334 coded, 11 left out |
| 20 | Recombination Analysis | 5 s | 1,502 crossovers in 100 real RILs (mean 15.0 per line); mean donor content 51 % |
| 21 | In silico BSA | 10 s | 2 loci (chr3 and chr8) found by all three window sizes |

\* Measured on the development PC with the settings in each README (some use fewer simulation replicates, epochs or folds than the defaults to stay short).

**One mapping population.** Tools 01-05, 07, 09, 10, 12, 13, 15-17, 19-21 are built on the same 100 real rice recombinant inbred lines (RILs), named MP001 ... MP100: 334 markers on 12 chromosomes,
parent 1 = 0, heterozygous = 1, parent 2 = 2 (the raw company files of tool 19 give exactly this table). The genotypes are real; whatever is simulated (a trait, sequencing reads) is built on the
real genotypes with known planted answers, and each README says so. The same traits run through the chain: Yield (QTL on chr1 and chr5) is used by the QTL mapping, GWAS, genes extraction,
OCS and phenotypic trial demos; Plant_Height (QTL on chr3 and chr8) by QTL mapping and the three bulked-segregant tools (05, 09, 21).

**Diversity-panel demos.** Tools 06 and 08 use real genotypes of the rice 3K panel that ships with TerraTools (sub-populations aus, indica 2, japonica, aromatic); tool 14 uses the public Rice Diversity Panel 1
(real genotypes and a real trait); tool 18 uses a rice 4K haplopanel file of 24 improved varieties and landraces; tool 11 uses real rice genes and live public databases, so its scores can drift slightly.
Results of the neural-network tools (BreedSight, Heterosis) vary a little between runs.

The inputs are made by `docs/make_rice_demos.py` (and its `rice_stage_*.py` files) and the outputs by `docs/run_rice_demos.py`, with fixed seeds, from the source files in `docs/demo_source`.
