OPTIMAL CROSS SELECTION - from phenotypes, markers and a genetic map to the crosses to make: MPV and usefulness of every cross, balanced against diversity  (run time about 20 s)

INPUT   input/phenotypes.csv      Genotype, Amylose_content (percent amylose) of 370 of the 378 rice inbred lines of the GSTP009 panel, copied unchanged from the sheet "breedsight" of GSTP009.xlsx. The other 8 lines have no value:
                                  they are genotyped only, candidates whose value is predicted from their markers.
        input/marker_matrix.csv   378 lines x 1,500 SNPs (0 / 1 / 2 copies of the first allele of the PLINK .bim file). The SNPs are evenly spaced along the 12 chromosomes from those with minor allele frequency >= 0.05, at most 2 % missing
                                  and at most 5 % heterozygous calls (IRGSP-1.0 positions in the names, Chr_Position).
        input/genetic_map.csv     Marker, Chromosome, cM. A PSEUDO map: cM = position in Mb x 4.3 (the rice average). The lines are unrelated, so there is no linkage map; the physical positions are real.
        input/markers.vcf         the same SNPs as a VCF (physical positions), for the case WITHOUT a genetic map.
        There are no marker effects and no relationship matrix to prepare: the tool estimates the effects from the phenotypes (rrBLUP) and calculates the relationship matrix (VanRaden).

STEPS   Genomic Selection > Optimal Cross Selection > the three files > Preview & Validate (378 genotypes x 1,500 markers on 12 chromosomes, 370 with a phenotype; marker heritability 0.76 and cross-validated accuracy 0.72:
        amylose content is controlled by a major gene (Waxy), so it is predicted well; 4,266 heterozygous calls are read as missing).  Trait Amylose_content, higher is better, the plan maximises usefulness.
        Population: Doubled haploids, generation 1, selected proportion 0.05, candidate pool 60.  Crosses 20, max per parent 4, penalty 30.  > Run.
        No genetic map? Choose "No map: use a VCF", select input/markers.vcf and enter a recombination rate of 4.3 cM per Mb (the rate of the pseudo map).

EXPECT  For every one of the 1,770 crosses among the 60 best candidates the tool calculates the MPV (mid-parent value), the standard deviation of the progeny and the usefulness = MPV + selection intensity x SD.
        Average of all crosses: MPV 8.0, usefulness 10.0; best cross d09d62e7.0 x 630c7f90.0 (MPV 9.0, progeny SD 1.37, usefulness 11.8).
        The plan of 20 crosses uses 20 parents and has a mean MPV of 8.3 and a mean usefulness of 11.1 at a group coancestry of 0.56 and a progeny inbreeding of 0.25. The coancestry is high because the best candidates are the lines
        with the highest genomic amylose values, and they are related; move the penalty toward 0 degrees for a higher usefulness (0 degrees: 11.5 with 15 parents, coancestry 0.67).
        The values are on a relative scale (the phenotypes are centred): only the differences between crosses matter. "Higher is better" is chosen only for the demo: for amylose a breeder often wants an intermediate value.
        Outputs: the crossing plan, the contribution of every parent, the usefulness / diversity table and plot for every penalty degree, the MPV and usefulness of all crosses (ocs_all_crosses.csv), the estimated marker effects
        (ocs_marker_effects.csv, reusable as a Marker, Effect file) and the relationship matrix that was calculated (ocs_relationship_matrix.csv).
