GENE PRIORITIZATION - rank the candidate genes of the blast QTL with public databases  (needs the internet; about 1 minute with a warm cache, longer the first time)

INPUT   input/candidate_genes.txt   16 genes (RAP-DB IDs) taken from the gene list of Genes Extraction (demo 10, the four blast QTL of demo 04): the 14 genes of those regions that carry a gene symbol
        (chr3: SIP32, OsETOL1, OsTDF1, OsPYL/RCAR4; chr4: GSD1, OsSTA132, OsNUC1-S, two genes named Pi63, PAO3; chr9: NP39; chr12: OsSHM3, OsABCG29, OsABCG30) and two genes with no symbol or
        description (Os03g0293850, Os12g0408800) as controls. The whole list of demo 10 (98 genes) can be used too, but it takes much longer.

STEPS   Trait Mapping > Gene Prioritization > Species: rice.  Trait: blast resistance.  Gene list: candidate_genes.txt. > Run.

EXPECT  The two Pi63 genes rank on top with the evidence level "Direct association": Os04g0620800 72.4 and Os04g0620950 60.7 (scores of 100). Both carry the trait annotation "blast disease (TO:0000074)",
        a disease-resistance protein domain, an Arabidopsis NB-ARC resistance-protein ortholog and two recent blast-resistance papers. Then OsSHM3 (25.7, "Direct association" through a "jasmonic acid sensitivity"
        trait annotation, an indirect link) and OsSTA132 (12.5, "Single line": a pathogen-effector related domain only). The other 12 genes score 0 or have no evidence at all ("No trait evidence").
        Evidence comes from Gramene trait annotations, Oryzabase curated gene names and trait classes (downloaded once and cached, nothing is added to the app), Plant Reactome pathways and PubMed
        co-mentions; each gene also gets a RAP-DB link; the score ranks the evidence, it is not a probability.

NOTE    The time depends on how fast Ensembl Plants, Gramene, Plant Reactome, NCBI and Oryzabase answer: the first run also downloads the Oryzabase list (about 11 MB); a repeat takes seconds (the app caches
        answers). Scores can change a little over time as the databases grow.

HONEST NOTES
        - The gene symbol "Pi63" comes from the annotation of the Nipponbare reference (RAP-DB); the tool's evidence shows these genes are described as blast-resistance genes, which is
          consistent with the largest QTL of demo 04 (chr4, LOD 7.3) lying on them. That is supporting evidence for a candidate, not proof that Pi63 explains the QTL of this panel.
        - A gene with no score is not "bad": it only has no public evidence for the trait.
