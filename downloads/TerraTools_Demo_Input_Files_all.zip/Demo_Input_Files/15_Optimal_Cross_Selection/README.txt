OPTIMAL CROSS SELECTION - from phenotypes, markers and a genetic map to the crosses to make: MPV and usefulness of every cross, balanced against diversity  (run time about 20 s)

INPUT   input/phenotypes.csv      Genotype, GYKGHA (grain yield, kg/ha) of 80 of the 100 lines of the mapping population (the other 20 lines are genotyped only: they are candidates whose value is predicted
                                  from their markers). REAL measurements.
        input/marker_matrix.csv   the 100 lines x 278 SNP marker matrix (0 / 1 / 2). REAL genotypes of the mapping population.
        input/genetic_map.csv     Marker, Chromosome, cM. REAL map: the positions the Linkage Mapping demo (03) calculated for these markers.
        input/markers.vcf         the same SNPs as a VCF (their real physical positions), for the case WITHOUT a genetic map.
        There are no marker effects and no relationship matrix to prepare: the tool estimates the effects from the phenotypes (rrBLUP) and calculates the relationship matrix (VanRaden).

STEPS   Genomic Selection > Optimal Cross Selection > the three files > Preview & Validate (100 genotypes x 278 markers on 12 chromosomes, 80 with a phenotype; the marker heritability
        is 0.36 and the five-fold cross-validated accuracy of the marker effects 0.30 - grain yield is a complex trait; 82 heterozygous calls are read as missing).  Trait GYKGHA, higher is better,
        the plan maximises usefulness.
        Population: Doubled haploids, generation 1, selected proportion 0.05, candidate pool 60.  Crosses 20, max per parent 4, penalty 30.  > Run.
        No genetic map? Choose "No map: use a VCF", select input/markers.vcf and enter a recombination rate of 5.6 cM per Mb (the Linkage Mapping map has 2,082 cM on about 373 Mb): the plan of crosses
        is similar (the values differ a little, because one rate for the whole genome is an approximation); a genetic map from Linkage Mapping is more accurate.

EXPECT  The marker effects are estimated from the 80 phenotyped lines. For every one of the 1,770 crosses among the 60 best candidates the tool calculates the MPV (mid-parent value: the mean of the
        two parents' genomic values), the standard deviation of the progeny (from the marker effects and the recombination along the map) and the
        usefulness = MPV + selection intensity (2.06) x standard deviation. Average of all crosses: MPV 443, usefulness 660 kg/ha; best cross IR127304-1214 x IR127304-1121 (MPV 571, progeny SD 144,
        usefulness 867).
        The plan of 20 crosses uses 20 parents and has a mean usefulness of 813 at a group coancestry of 0.106 and a progeny inbreeding of 0; truncation selection (the best parents mated
        at random) gives 784 at a coancestry of 0.169 and an inbreeding of 0.120. Move the penalty toward 0 degrees for a higher usefulness and fewer parents (0 degrees: 841 with 11 parents).
        Setting "The plan maximises" to MPV only picks the crosses of the best parents by their mid-parent value alone (it ignores how much the progeny vary).
        The values are on a relative scale (the phenotypes are centred): only the differences between crosses matter.
        Outputs: the crossing plan (MPV, progeny SD, usefulness, kinship of every cross), the contribution of every parent, the usefulness / diversity table and plot for every penalty degree,
        the MPV and usefulness of all crosses (ocs_all_crosses.csv), the estimated marker effects (ocs_marker_effects.csv, reusable as a Marker, Effect file) and the relationship matrix
        that was calculated (ocs_relationship_matrix.csv).
