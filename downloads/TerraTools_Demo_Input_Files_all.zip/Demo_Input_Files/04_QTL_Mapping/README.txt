QTL MAPPING - SIM, CIM and MQM on real traits  (run time about 10-30 s per run, the permutation test included)

INPUT   input/genotypes_QTL_format.csv   the "QTL Mapping input" file of Linkage Mapping (demo 03): 286 markers on the 12-chromosome map x 100 rice RILs (REAL genotypes).
        input/phenotypes.csv   Line + the 19 REAL traits measured on the same lines: AGR, DWR_25, DWR_55, DWS_25, DWS_55, DWSD_25, DWSD_55, FWSD_25, FWSD_55, GRM, GYKGHA, NPT, PH, PL, PY, RGR, SDH_25,
        SDH_55, SPAD. Nothing is simulated. PH (plant height, cm) is the reference trait: of the 19 traits it gave the most QTL (3; SDH_55 also 3 but with a lower LOD); GYKGHA is the grain yield (kg/ha).

STEPS   Trait Mapping > QTL Mapping > load the two files (genotypes and phenotypes).
        Run 1: trait PH, SIM, fixed LOD 3.     Run 2: trait PH, CIM, permutation test (1000 permutations, 5 %).     Run 3: trait PH, MQM, permutation.
        Run 4: AGR, CIM, permutation.          Run 5: NPT, CIM, permutation (a trait without a QTL).

EXPECT  PH, SIM at LOD 3:  chr1 (chr01_38632196, LOD 14.6, 49 % of the variance) and chr2 (chr02_316859, LOD 3.1, 13 %) - the chr4 QTL is missed at the fixed threshold.
        PH, CIM with the permutation threshold (LOD 3.31): three QTL - chr1 chr01_38632196 (LOD 15.8, 49 %), chr2 chr02_316859 (LOD 4.0, 13 %) and chr4 chr04_30174083 (LOD 4.2, 8 %).
        PH, MQM (threshold 3.30): the same three QTL.  The chr1 peak lies 0.25 Mb from the green-revolution gene SD1 (Os01g0883800, GA20ox2 / C20ox2, 38.38 Mb).
        AGR, CIM (threshold 3.21): one QTL, chr1 chr01_38632196 (LOD 13.7, 40 %) - the same locus.   NPT, CIM (threshold 3.20): 0 QTL.
        expected_output/ holds, per run, the QTL table, the full scan, the Manhattan plot and the chromosome ideogram (the linkage-map-style picture with the QTL in red).
