QTL-SEQ - bulked segregant analysis from a VCF  (run time about 30 s with 1000 simulation replicates)

INPUT   input/qtlseq_bulks.vcf   one joint VCF with four samples (Parent1, Parent2, HighBulk, LowBulk): 3,731 SNPs, one every ~100 kb along the 12 rice chromosomes.
        The two bulks are the 20 tallest and the 20 shortest lines of the mapping population (PH of the mapping population, three QTL: chr1 at 38.6 Mb, chr2, chr4; the former QTL Mapping demo, demo 04 now holds the GSTP009 blast data).
        The allele of every SNP in every line is taken from the REAL marker genotypes of the neighbouring markers; the sequencing reads (about 40 x per bulk, 1 % errors) are SIMULATED.

STEPS   Trait Mapping > QTL-Seq > Input: VCF files.  Choose qtlseq_bulks.vcf for high bulk, low bulk and parental VCF (the same file three times).
        Plants per bulk: 20 and 20, population RIL, index parent: parent 2.  Settings tab: simulation replicates 1000 (default 10000); call a QTL where the window mean passes the 99 % level.
        Turn on "advanced settings" and type the sample names: HighBulk, LowBulk, Parent1, Parent2.  > Run QTL-seq.

EXPECT  3,731 informative SNPs, 3,392 retained after the filters (339 removed by the SNP-index filter); QTL at the 99 % level, all enriched in the high bulk:
        QTL1 chr1 30.85-41.23 Mb, peak 36.48 Mb, peak delta SNP-index 0.83 (the SD1 region, 38.38 Mb, is inside);
        QTL2-QTL6 on chr9 (0.7-11.4 Mb, peak delta 0.48-0.53): overlapping windows of one broad region, a weaker locus that also showed in the QTL scan of this population (LOD 2.7, below the threshold).
        The chr2 and chr4 QTL do not pass the 99 % level in 20-line bulks.
