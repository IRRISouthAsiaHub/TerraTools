PHENOTYPIC DATA ANALYSIS - augmented field trial in three environments  (run time about 5-30 s per analysis)

INPUT   input/phenotypic_trial.csv   180 plots: Genotype, Environment, Rep, Block, GYKGHA (grain yield, kg/ha), PH (plant height, cm), PL (panicle length, cm).
        40 entries of the rice mapping population (IR127304-1xxx, spread over the whole yield range) + 4 rice checks (Check_IR64, Check_Swarna, Check_Sahbhagi,
        Check_Nipponbare), augmented design with 5 blocks, 3 environments (Dry_2024, Wet_2024, Dry_2025).
        The entries are lines of the real mapping population of the other demos and the genetic value of every entry is its REAL measurement (GYKGHA, PH, PL of the
        QTL Mapping demo 04); the FIELD PART is SIMULATED: environment shift, block effect, plot error and the four checks.

STEPS   Data Analysis > Phenotypic Data Analysis > Data & Design > Browse: phenotypic_trial.csv  (design: Augmented RCBD is picked from the Block column).
        Analyses tab: pick an analysis, keep all three traits ticked, press its Run button. Each analysis runs on its own (about 5-30 s each);
        run Descriptives, Heritability, BLUPs, ANOVA, PCA, Clustering (3 clusters, k-means) and Stability & GxE (trait GYKGHA) to fill the tabs.

EXPECT  Mean grain yield (kg/ha) per environment (entries): Dry_2024 1,885, Dry_2025 1,906, Wet_2024 2,432 - the wet season yields most.
        Heritability (pooled over environments), on a plot basis / on an entry-mean basis:
              GYKGHA 0.69 / 0.87     PH 0.97 / 0.99     PL 0.94 / 0.98
        (per environment, yield: Dry_2024 0.76, Wet_2024 0.85, Dry_2025 0.11 - that season has the largest plot error).
        BLUPs (GYKGHA, pooled over environments): 40 entries, H2 Cullis 0.86, mean reliability 0.84; best entry IR127304-1153 (BLUP +1,013, SE 198, predicted yield 3,086 kg/ha),
              then IR127304-1279 (+641) and IR127304-1181 (+641). Downloads > BLUPs (.xlsx) gives the BLUP table and the variance/heritability table. The 4 checks are fixed effects and have no BLUP.
        ANOVA (pooled): genotypes (adjusted for blocks) are significant for every trait, P < 0.001 (GYKGHA F 7.5, PH F 89.4, PL F 43.2); the environments differ too.
        Correlation (44 genotypes): GYKGHA - PH r 0.58 (P < 0.001), PH - PL r 0.45 (P = 0.002), GYKGHA - PL r 0.10 (not significant).
        Design Check: 5 blocks, 4 repeated checks, 40 single entries per environment.  PCA, Clustering and Stability tabs fill with plots.
        expected_output/ holds every table (CSV), the main figures (PNG) and the Excel workbooks (Phenotypic_Analysis.xlsx, ANOVA_tables.xlsx, BLUPs.xlsx).
        (The field part is simulated with a fixed seed; yours should match to the printed digits.)
